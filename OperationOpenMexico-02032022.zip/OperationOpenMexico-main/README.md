# OperationOpenMexico
Operation Open Mexico (Demant)


dotnet publish -c Release -r win-x64 --self-contained  
sc create OpenMexico binPath = C:\teste\OpenMexico.App.exe