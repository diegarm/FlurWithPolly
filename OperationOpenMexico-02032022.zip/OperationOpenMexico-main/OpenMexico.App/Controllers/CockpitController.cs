﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OpenMexico.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OpenMexico.App.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CockpitController : ControllerBase
    {
        private readonly ICockpitService _cockpitService;

        public CockpitController(ICockpitService cockpitService)
        {
            _cockpitService = cockpitService;
            _cockpitService.Process();
        }


        [HttpPost("/api/process/")]
        public IActionResult PostAsync()
        {
            _cockpitService.Process();
            return Ok("Process End");
        }
    }
}
