﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{
    [Table("SALESORDERITEM")]
    public class SalesOrderItem
    {
        public SalesOrder sales { get; set; }

        [Key]
        public int Id { get; set; }
        public string Articulo { get; set; }
        public string Nombre { get; set; }
        public string Cant { get; set; }
        public string Unidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Neto { get; set; }
        public decimal Total { get; set; }
    }

}
