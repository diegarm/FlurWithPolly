﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{
    [Table("PENDINGSALESITEMS")]
    public class PendingSalesItems
    {
        public PendingSales pendingSales { get; set; }

        [Key]
        public int Id { get; set; }
        public string Articulo { get; set; }
        public string Nombre { get; set; }
        public string Unidad { get; set; }
        public decimal Cant { get; set; }
        public decimal PendienteaEntregar { get; set; }

        

    }

}
