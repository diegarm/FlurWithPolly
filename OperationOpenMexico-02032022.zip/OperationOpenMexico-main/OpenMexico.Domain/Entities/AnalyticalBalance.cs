﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{

    [Table("ANALYTICALBALANCE")]
    public class AnalyticalBalance
    {

        [Key]
        public int Id { get; set; }
        public string Cuenta { get; set; }
        public string Descripcion { get; set; }
        public decimal SaldoInicial { get; set; }
        public decimal DebeMovimientos { get; set; }
        public decimal HaberMovimientos { get; set; }
        public decimal DebeAcumulado { get; set; }
        public decimal HaberAcumulado { get; set; }
        public decimal Saldo { get; set; }
    }

}
