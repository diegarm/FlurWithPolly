﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{

    [Table("SALESORDER")]
    public class SalesOrder
    {
        [Key]
        public int Id { get; set; }
        public long Nro { get; set; }
        public string NroOrdenCompraCliente { get; set; }
        public DateTime Fecha { get; set; }
        public DateTime FechaUltActualizacion { get; set; }
        public string Cliente { get; set; }
        public string NombredelCliente { get; set; }
        public string Moneda { get; set; }
        public decimal SubTotal { get; set; }
        public decimal Total { get; set; }
        public string Vendedor { get; set; }
        public string Departamento { get; set; }
        public string Aprobado { get; set; }
        public string GrupodeVenta { get; set; }
        public string Cerrado { get; set; }
        public string Facturado { get; set; }
        public string Entregado { get; set; }

        public List<SalesOrderItem> SalesOrderItem { get; set; }
    }

}
