﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{
    [Table("BALANCE")]

    public class Balance
    {
        [Key]
        public int Id { get; set; }

        public string Etiqueta { get; set; }
        public string Descripcion { get; set; }
        public decimal Total { get; set; }

        public List<BalanceItems> BalanceItems { get; set; }  

    }

}
