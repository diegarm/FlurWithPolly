﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{

    [Table("RECEIVABLE")]
    public class Receivable
    {
        [Key]
        public int Id { get; set; }
        public string Cliente { get; set; }
        public string Nombre { get; set; }
        public string Vencido { get; set; }
        public decimal Saldo { get; set; }
        public List<SaldoReceivable> SaldoReceivable { get; set; }
    }

  
}
