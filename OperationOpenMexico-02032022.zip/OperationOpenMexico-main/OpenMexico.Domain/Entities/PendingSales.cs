﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities
{
    [Table("PENDINGSALES")]
    public class PendingSales
    {

        [Key]
        public int Id { get; set; }
        public long Pedido { get; set; }
        public DateTime FechaEntrega { get; set; }
        public List<PendingSalesItems> pendingSalesItems { get; set; }

    }


}
