﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities.InvoiceList
{
    [Table("INVOICE")]
    public class Invoice
    {

        [Key]
        public int Id { get; set; }
        public long Nro { get; set; }
        public string NroFolioFactura { get; set; }
        public string TipodeFactura { get; set; }
        public string Tipo { get; set; }
        public DateTime FechaTrans { get; set; }
        public DateTime FechaFactura { get; set; }
        public DateTime FechaVto { get; set; }
        public string Cliente { get; set; }
        public string NombredelCliente { get; set; }
        public string Vendedor { get; set; }
        public string Sucursal { get; set; }
        public string Moneda { get; set; }
        public decimal IVA { get; set; }
        public decimal Impuestos { get; set; }
        public decimal SubTotal { get; set; }
        public decimal Total { get; set; }
        public string RegistrodeOrigen { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaUltActualizacion { get; set; }
        public string Computadora { get; set; }
        public string Departamento { get; set; }
        public string TipoFormulario { get; set; }
        public string Aprobado { get; set; }
        public string Referencia { get; set; }
        public string Etiquetas { get; set; }
        public string Idioma { get; set; }
        public string Turno { get; set; }
        public string TurnoNro { get; set; }
        public string Invalido { get; set; }
        public string Usuario { get; set; }
        public string Impresoa { get; set; }
        public decimal TasadeCambio { get; set; }
        public string Pais { get; set; }
        public string Estado { get; set; }
        public string Municipio { get; set; }
        public string CodigoPostal { get; set; }
        public string GrupodeVenta { get; set; }
        public decimal CostoTotal { get; set; }
        public string CentrodeCostodeCliente { get; set; }
        public string AcuerdodeDescuentos { get; set; }
        public string FormadeEntrega { get; set; }
        public string TipoOperacion { get; set; }
        public string TerminosdeEntrega { get; set; }
        public string ContactodeEntrega { get; set; }
        public string FacturaInterna { get; set; }
        public string TerminosdePago { get; set; }
        public string Garantes { get; set; }
        public string AcuerdodePrecios { get; set; }
        public string ActualizaStock { get; set; }
        public string Contacto { get; set; }
        public DateTime FechaServicio { get; set; }
        public string Clausulas { get; set; }
        public string Comentario { get; set; }

        public string FacturaenGrupo { get; set; }
        public string DepositodeStock { get; set; }
        public string Campana { get; set; }
        public string CuotasManuales { get; set; }
        public string Cuestionada { get; set; }
        public string CategoriadeFactura { get; set; }
        public string RegimenFiscal { get; set; }
        public string TipodeComprobante { get; set; }
        public string ValidadoElectrónicamente { get; set; }

        public DateTime Fecha2doVto { get; set; }

        public string FormadeCancelacion { get; set; }
        public DateTime FechayHoraCertificacion { get; set; }
        public DateTime FechayHoradeEmision { get; set; }
        public string TXTGenerado { get; set; }
        public string UsodelCFDI { get; set; }
        public string TipodeRelacion { get; set; }
        public string InvalidadoElectronicamente { get; set; }
        public string Comercioexterior { get; set; }
        public string ClavedePedimento { get; set; }
        public string CertificadodeOrigen { get; set; }
        public string Incoterm { get; set; }
        public string Subdivision { get; set; }
        public string VendedorCliente { get; set; }
        public string GrupodeClientesCliente { get; set; }
        public string SegmentodeMercadoCliente { get; set; }
        public string CodigoSucursal { get; set; }
        public List<InvoiceItem> InvoiceItem { get; set; }
    }

}
