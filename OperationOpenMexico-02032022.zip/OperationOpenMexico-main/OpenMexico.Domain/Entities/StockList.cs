﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities.SalesOrderList
{
    [Table("STOCKLIST")]
    public class StockList
    {
        [Key]
        public long Id { get; set; }
        public string Articulo { get; set; }
        public string Descripcion { get; set; }
        public string Grupo { get; set; }
        public string Subgrupo { get; set; }
        public string Posicion { get; set; }
        public string NroSerie { get; set; }
        public string DepositodeStock { get; set; }
        public string Unidad { get; set; }
        public decimal Stock { get; set; }
        public string NroPedimento { get; set; }
        public string Lote { get; set; }
    }
}
