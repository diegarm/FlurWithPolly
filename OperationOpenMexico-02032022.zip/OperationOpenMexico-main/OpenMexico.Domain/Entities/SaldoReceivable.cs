﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OpenMexico.Domain.Entities
{
    [Table("SALDORECEIVABLE")]
    public class SaldoReceivable
    {
        public Receivable Receivable { get; set; }

        [Key]
        public int Id { get; set; }

        public string Tipo { get; set; }
        public string Nro { get; set; }
        public DateTime FechaFactura { get; set; }
        public DateTime FechaVto { get; set; }
        public string Dias { get; set; }
        public string Moneda { get; set; }
        public decimal Total { get; set; }
        public decimal Saldo { get; set; }
        public decimal Acum { get; set; }
        public string Vendedor { get; set; }
    }

}
