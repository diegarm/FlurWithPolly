﻿using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Interfaces
{
    public interface IInvoiceRepository : IGeneralRepository
    {
     
    }
}
