﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OpenMexico.Application.Interfaces;
using OpenMexico.Application.Mappings;
using OpenMexico.Application.Services;
using OpenMexico.Domain.Interfaces;
using OpenMexico.Infrastructure.Data.Context;
using OpenMexico.Infrastructure.Data.Repository;
using System;
using System.Threading.Tasks;

namespace OpenMexico.Infrastructure.IoC
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(
                    this IServiceCollection services,
                    IConfiguration configuration,
                    IWebHostEnvironment currentEnvironment)
        {


            services.AddDbContext<OpenMexicoContext>(
               context => {
                   context.UseSqlServer(configuration.GetConnectionString("DataBaseOpenMexico"));
                   
               },ServiceLifetime.Transient);

            services.AddScoped<IInvoiceRepository, InvoiceRepository>();
            services.AddScoped<ICockpitService, CockpitService>();
            services.AddScoped<IStockRepository, StockRepository>();
            services.AddScoped<ISalesOrderRepository, SalesOrderRepository>();
            services.AddScoped<IReceivableRepository, ReceivableRepository>();
            services.AddScoped<IAnalyticsBalanceRepository, AnalyticsBalanceRepository>();
            services.AddScoped<IBalanceRepository, BalanceRepository>();
            services.AddScoped<IPendingSalesRepository, PendingSalesRepository>();

            return services;
        }

        public static IServiceCollection AddAutoMapperConfiguration(this IServiceCollection services)
        {
            services.AddAutoMapper(
                typeof(DomainToViewModelMappingProfile),
                typeof(ViewModelToDomainMappingProfile)
                );

            return services;
        }

        public static async Task<IServiceCollection> AddServiceCyclicAsync(this IServiceCollection services, IConfiguration configuration)
        {
            var sp = services.BuildServiceProvider();
            var cockpitService = sp.GetService<ICockpitService>();
            int timeDelaySeconds = 100;
            int.TryParse(configuration["timeDelaySeconds"].ToString(), out timeDelaySeconds);
            cockpitService.ProcessCyclic(timeDelaySeconds);

            return services;

        }



    }
}
