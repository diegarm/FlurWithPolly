﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OpenMexico.Domain.Entities.SalesOrderList
{
    public class StockViewModel
    {
        [JsonProperty("Artículo")]
        public string Articulo { get; set; }

        [JsonProperty("Descripción")]
        public string Descripcion { get; set; }
        public string Grupo { get; set; }
        public string Subgrupo { get; set; }

        [JsonProperty("Posición")]
        public string Posicion { get; set; }

        [JsonProperty("Nro Serie")]
        public string NroSerie { get; set; }

        [JsonProperty("Depósito de Stock")]
        public string DepositodeStock { get; set; }
        public string Unidad { get; set; }
        public decimal Stock { get; set; }

        [JsonProperty("Nro Pedimento")]
        public string NroPedimento { get; set; }
        public string Lote { get; set; }
    }
}
