﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class InvoiceItemViewModel
    {

        [JsonProperty("Cód. Artículo")]
        public string CodArticulo { get; set; }
        public string Nombre { get; set; }

        [JsonProperty("Cant.")]
        public decimal Cant { get; set; }
        public decimal Precio { get; set; }
        public decimal Descuento { get; set; }

        [JsonProperty("Neto Fila")]
        public decimal NetoFila { get; set; }

        [JsonProperty("Total Fila")]
        public decimal TotalFila { get; set; }
        public decimal Costo { get; set; }

        [JsonProperty("Costo Operativo")]
        public decimal CostoOperativo { get; set; }

        [JsonProperty("Cost Op. Total")]
        public decimal CostOpTotal { get; set; }

        public decimal Ganancia { get; set; }

        [JsonProperty("% Ganancia")]
        public float PorcGanancia { get; set; }

    }
}
