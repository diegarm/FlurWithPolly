﻿using Newtonsoft.Json;
using OpenMexico.Application.Converters;
using System;
using System.Collections.Generic;


namespace OpenMexico.Application.ViewModel
{

    public class InvoiceViewModel
    {
        public long Nro { get; set; }
        
        [JsonProperty("Nro Folio Factura")]
        public string NroFolioFactura { get; set; }

        [JsonProperty("Tipo de Factura")]
        public string TipodeFactura { get; set; }


        public string Tipo { get; set; }

        [JsonProperty("Fecha Trans.")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaTrans { get; set; }

        [JsonProperty("Fecha Factura")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaFactura { get; set; }

        [JsonProperty("Fecha Vto.")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaVto { get; set; }

        public string Cliente { get; set; }

        [JsonProperty("Nombre del Cliente")]
        public string NombredelCliente { get; set; }
        public string Vendedor { get; set; }
        public string Sucursal { get; set; }
        public string Moneda { get; set; }
        public decimal IVA { get; set; }
        public decimal Impuestos { get; set; }

        [JsonProperty("Sub-Total")]
        public decimal SubTotal { get; set; }
        public decimal Total { get; set; }

        [JsonProperty("Registro de Origen")]
        public string RegistrodeOrigen { get; set; }

        [JsonProperty("Fecha Creación")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaCreacion { get; set; }

        [JsonProperty("Fecha Ult. Actualización")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaUltActualizacion { get; set; }

        public string Computadora { get; set; }
        public string Departamento { get; set; }

        [JsonProperty("Tipo Formulario")]
        public string TipoFormulario { get; set; }
        public string Aprobado { get; set; }
        public string Referencia { get; set; }
        public string Etiquetas { get; set; }
        public string Idioma { get; set; }
        public string Turno { get; set; }

        [JsonProperty("Turno Nro.")]
        public string TurnoNro { get; set; }

        [JsonProperty("Inválido")]
        public string Invalido { get; set; }
        public string Usuario { get; set; }

        [JsonProperty("Impreso/a")]
        public string Impresoa { get; set; }

        [JsonProperty("Tasa de Cambio")]
        public decimal TasadeCambio { get; set; }

        [JsonProperty("País")]
        public string Pais { get; set; }
        public string Estado { get; set; }
        public string Municipio { get; set; }

        [JsonProperty("Código Postal")]
        public string CodigoPostal { get; set; }

        [JsonProperty("Grupo de Venta")]
        public string GrupodeVenta { get; set; }

        [JsonProperty("Costo Total")]
        public decimal CostoTotal { get; set; }

        [JsonProperty("Centro de Costo de Cliente")]
        public string CentrodeCostodeCliente { get; set; }

        [JsonProperty("Acuerdo de Descuentos")]
        public string AcuerdodeDescuentos { get; set; }

        [JsonProperty("Forma de Entrega")]
        public string FormadeEntrega { get; set; }

        [JsonProperty("Tipo Operación")]
        public string TipoOperacion { get; set; }

        [JsonProperty("Términos de Entrega")]
        public string TerminosdeEntrega { get; set; }

        [JsonProperty("Contacto de Entrega")]
        public string ContactodeEntrega { get; set; }

        [JsonProperty("Factura Interna")]
        public string FacturaInterna { get; set; }

        [JsonProperty("Términos de Pago")]
        public string TerminosdePago { get; set; }

        public string Garantes { get; set; }

        [JsonProperty("Acuerdo de Precios")]
        public string AcuerdodePrecios { get; set; }

        [JsonProperty("Actualiza Stock")]
        public string ActualizaStock { get; set; }
        public string Contacto { get; set; }

        [JsonProperty("Fecha Servicio")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaServicio { get; set; }

        [JsonProperty("Cláusulas")]
        public string Clausulas { get; set; }
        public string Comentario { get; set; }

        [JsonProperty("Factura en Grupo")]
        public string FacturaenGrupo { get; set; }

        [JsonProperty("Depósito de Stock")]
        public string DepositodeStock { get; set; }

        [JsonProperty("Campaña")]
        public string Campana { get; set; }

        [JsonProperty("Cuotas Manuales")]
        public string CuotasManuales { get; set; }
        public string Cuestionada { get; set; }

        [JsonProperty("Categoria de Factura")]
        public string CategoriadeFactura { get; set; }

        [JsonProperty("Regimen Fiscal")]
        public string RegimenFiscal { get; set; }

        [JsonProperty("Tipo de Comprobante")]
        public string TipodeComprobante { get; set; }

        [JsonProperty("Validado Electrónicamente")]
        public string ValidadoElectrónicamente { get; set; }

        [JsonProperty("Fecha 2do Vto.")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime Fecha2doVto { get; set; }

        [JsonProperty("Forma de Cancelación")]
        public string FormadeCancelacion { get; set; }

        [JsonProperty("Fecha y Hora Certificación")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechayHoraCertificacion { get; set; }

        [JsonProperty("Fecha y Hora de Emisión")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechayHoradeEmision { get; set; }
        
        [JsonProperty("TXT Generado")]
        public string TXTGenerado { get; set; }

        [JsonProperty("Uso del CFDI")]
        public string UsodelCFDI { get; set; }

        [JsonProperty("Tipo de Relación")]
        public string TipodeRelacion { get; set; }

        [JsonProperty("Invalidado Electrónicamente")]
        public string InvalidadoElectronicamente { get; set; }

        [JsonProperty("Comercio exterior")]
        public string Comercioexterior { get; set; }

        [JsonProperty("Clave de Pedimento")]
        public string ClavedePedimento { get; set; }

        [JsonProperty("Certificado de Origen")]
        public string CertificadodeOrigen { get; set; }
        public string Incoterm { get; set; }
        public string Subdivision { get; set; }

        [JsonProperty("Vendedor (Cliente)")]
        public string VendedorCliente { get; set; }

        [JsonProperty("Grupo de Clientes (Cliente)")]
        public string GrupodeClientesCliente { get; set; }

        [JsonProperty("Segmento de Mercado (Cliente)")]
        public string SegmentodeMercadoCliente { get; set; }

        [JsonProperty("Código (Sucursal)")]
        public string CodigoSucursal { get; set; }

        public List<InvoiceItemViewModel> subrows { get; set; } = new();
    }

}
