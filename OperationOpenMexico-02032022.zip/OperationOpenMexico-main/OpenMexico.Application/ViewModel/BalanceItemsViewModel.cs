﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class BalanceItemsViewModel
    {
        public string Cuenta { get; set; }
        public string Nombre { get; set; }
        public decimal Monto { get; set; }
    }
}
