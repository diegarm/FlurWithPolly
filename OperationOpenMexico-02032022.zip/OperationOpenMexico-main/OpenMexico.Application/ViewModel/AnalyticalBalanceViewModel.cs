﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class AnalyticalBalanceViewModel
    {
        
        public string Cuenta { get; set; }

        [JsonProperty("Descripción")]
        public string Descripcion { get; set; }
        public decimal SaldoInicial { get; set; }
        public decimal DebeMovimientos { get; set; }
        public decimal HaberMovimientos { get; set; }
        public decimal DebeAcumulado { get; set; }
        public decimal HaberAcumulado { get; set; }
        public decimal Saldo { get; set; }
        
    }
}
