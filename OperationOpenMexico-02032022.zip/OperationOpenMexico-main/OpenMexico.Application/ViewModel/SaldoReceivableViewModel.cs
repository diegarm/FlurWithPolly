﻿using Newtonsoft.Json;
using OpenMexico.Application.Converters;
using System;

namespace OpenMexico.Application.ViewModel
{
    public class SaldoReceivableViewModel
    {
        public string Tipo { get; set; }
        public string Nro { get; set; }

        [JsonProperty("Fecha Factura")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaFactura { get; set; }

        [JsonProperty("Fecha Vto.")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaVto { get; set; }

        [JsonProperty("Días")]
        public string Dias { get; set; }
        public string Moneda { get; set; }
        public decimal Total { get; set; }
        public decimal Saldo { get; set; }

        [JsonProperty("Acum.")]
        public decimal Acum { get; set; }
        public string Vendedor { get; set; }
    }
}
