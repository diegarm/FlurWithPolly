﻿using Newtonsoft.Json;

namespace OpenMexico.Application.ViewModel
{
    public class SalesOrderItemViewModel
    {
        [JsonProperty("Artículo")]
        public string Articulo { get; set; }
        public string Nombre { get; set; }
        [JsonProperty("Cant.")]
        public string Cant { get; set; }
        public string Unidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Neto { get; set; }
        public decimal Total { get; set; }
    }
}
