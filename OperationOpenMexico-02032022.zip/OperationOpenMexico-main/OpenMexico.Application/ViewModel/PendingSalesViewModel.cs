﻿using Newtonsoft.Json;
using OpenMexico.Application.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class PendingSalesViewModel
    {
        public long Pedido { get; set; }

        [JsonProperty("Fecha Entrega")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaEntrega { get; set; }

        public List<PendingSalesItemsViewModel> subrows { get; set; } = new();
    }
}
