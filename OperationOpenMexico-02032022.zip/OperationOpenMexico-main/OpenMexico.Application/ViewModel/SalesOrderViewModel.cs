﻿using Newtonsoft.Json;
using OpenMexico.Application.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class SalesOrderViewModel
    {
        public long Nro { get; set; }
        
        [JsonProperty("Nro Orden Compra Cliente")]
        public string NroOrdenCompraCliente { get; set; }

        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime Fecha { get; set; }

        [JsonProperty("Fecha Ult. Actualización")]
        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime FechaUltActualizacion { get; set; }
        public string Cliente { get; set; }

        [JsonProperty("Nombre del Cliente")]
        public string NombredelCliente { get; set; }
        public string Moneda { get; set; }
        public decimal SubTotal { get; set; }
        public decimal Total { get; set; }
        public string Vendedor { get; set; }
        public string Departamento { get; set; }
        public string Aprobado { get; set; }

        [JsonProperty("Grupo de Venta")] 
        public string GrupodeVenta { get; set; }
        public string Cerrado { get; set; }
        public string Facturado { get; set; }
        public string Entregado { get; set; }

        public List<SalesOrderItemViewModel> subrows { get; set; } = new();
    }
}
