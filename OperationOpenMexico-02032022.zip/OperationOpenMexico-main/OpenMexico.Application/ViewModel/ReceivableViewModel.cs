﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class ReceivableViewModel
    {
        public string Cliente { get; set; }
        public string Nombre { get; set; }
        public string Vencido { get; set; }
        public decimal Saldo { get; set; }

        [JsonPropertyName("subrows")]
        public List<SaldoReceivableViewModel> subrows { get; set; } = new();
    }
}
