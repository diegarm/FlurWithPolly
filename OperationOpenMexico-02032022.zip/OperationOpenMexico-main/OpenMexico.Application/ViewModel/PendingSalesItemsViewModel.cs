﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.ViewModel
{
    public class PendingSalesItemsViewModel
    {
        [JsonProperty("Artículo")]
        public string Articulo { get; set; }
        public string Nombre { get; set; }
        public string Unidad { get; set; }
        [JsonProperty("Cant.")]
        public decimal Cant { get; set; }

        [JsonProperty("Pendiente a Entregar")]
        public decimal PendienteaEntregar { get; set; }


    }
}
