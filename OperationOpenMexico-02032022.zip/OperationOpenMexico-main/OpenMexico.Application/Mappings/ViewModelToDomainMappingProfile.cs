﻿using AutoMapper;
using OpenMexico.Application.ViewModel;
using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using OpenMexico.Domain.Entities.SalesOrderList;

namespace OpenMexico.Application.Mappings
{
    public class ViewModelToDomainMappingProfile : Profile
    {
        public ViewModelToDomainMappingProfile()
        {
            CreateMap<InvoiceViewModel, Invoice>()
                .ForMember(dest => dest.InvoiceItem, opt => opt.MapFrom(src => src.subrows));
            
            CreateMap<InvoiceItemViewModel,InvoiceItem>();
            CreateMap<StockViewModel, StockList>();
            CreateMap<SalesOrderViewModel, SalesOrder>()
                .ForMember(dest => dest.SalesOrderItem, opt => opt.MapFrom(src => src.subrows));

            CreateMap<SalesOrderItemViewModel,SalesOrderItem>();

            CreateMap<ReceivableViewModel,Receivable>()
                .ForMember(dest => dest.SaldoReceivable, opt => opt.MapFrom(src => src.subrows));

            CreateMap<SaldoReceivableViewModel,SaldoReceivable>();

            CreateMap<AnalyticalBalanceViewModel,AnalyticalBalance>();

            CreateMap<BalanceViewModel,Balance>()
                .ForMember(dest => dest.BalanceItems, opt => opt.MapFrom(src => src.subrows));

            CreateMap<BalanceItemsViewModel,BalanceItems>();



            CreateMap<PendingSalesViewModel,PendingSales>()
                .ForMember(dest => dest.pendingSalesItems, opt => opt.MapFrom(src => src.subrows));

            CreateMap<PendingSalesItemsViewModel, PendingSalesItems>();

        }
    }
}
