﻿using AutoMapper;
using OpenMexico.Application.ViewModel;
using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using OpenMexico.Domain.Entities.SalesOrderList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.Mappings
{
    public class DomainToViewModelMappingProfile : Profile
    {
        public DomainToViewModelMappingProfile()
        {

            CreateMap<StockList, StockViewModel>();
            
            CreateMap<SalesOrder, SalesOrderViewModel>()
                .ForMember(dest => dest.subrows, opt => opt.MapFrom(src => src.SalesOrderItem));

            CreateMap<SalesOrderItem, SalesOrderItemViewModel>();

            CreateMap<Invoice, InvoiceViewModel>()
                .ForMember(dest => dest.subrows, opt => opt.MapFrom(src => src.InvoiceItem));

            CreateMap<InvoiceItem, InvoiceItemViewModel>();

            CreateMap<Receivable, ReceivableViewModel>()
                .ForMember(dest => dest.subrows, opt => opt.MapFrom(src => src.SaldoReceivable));

            CreateMap<SaldoReceivable, SaldoReceivableViewModel>();

            CreateMap<AnalyticalBalance, AnalyticalBalanceViewModel>();

            CreateMap<Balance, BalanceViewModel>()
                .ForMember(dest => dest.subrows, opt => opt.MapFrom(src => src.BalanceItems));

            CreateMap<BalanceItems, BalanceItemsViewModel>();


            CreateMap<PendingSales, PendingSalesViewModel>()
                .ForMember(dest => dest.subrows, opt => opt.MapFrom(src => src.pendingSalesItems));

            CreateMap<PendingSalesItems, PendingSalesItemsViewModel>();

        }
    }
}

