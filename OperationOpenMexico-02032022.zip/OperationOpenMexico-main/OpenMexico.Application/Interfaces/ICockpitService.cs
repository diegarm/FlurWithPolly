﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.Interfaces
{
    public interface ICockpitService
    {
        void Process();
        void ProcessCyclic(int timeDelay);
    }
}
