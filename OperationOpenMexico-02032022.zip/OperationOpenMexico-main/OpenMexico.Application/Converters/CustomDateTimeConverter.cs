﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.Converters
{
    public class CustomDateTimeConverter : DateTimeConverterBase
    {
        private readonly string CULTURE_INFO = "es-AR";

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var dataString = (string)reader.Value;

            if (String.IsNullOrEmpty(dataString))
            {
                return DateTime.MinValue;
            }
            else
            {
                DateTime date = Convert.ToDateTime(dataString, (new System.Globalization.CultureInfo(CULTURE_INFO)));
                return date;
            }


        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}
