﻿using Newtonsoft.Json;
using OpenMexico.Application.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;

using System.Threading.Tasks;

namespace OpenMexico.Application.Clients
{
    public class ReceivableClient
    {
        private readonly HttpClient _httpClient;

        public ReceivableClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<ReceivableViewModel>> GetReceivablesAsync()
        {
            var result = await new AuthClient(_httpClient).Autheticate();

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.token);
            var response = await _httpClient.GetAsync("AccReceivable?format=JSON");

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore
            };

            var stringJson = await response.Content.ReadAsStringAsync();
            var resultDes = JsonConvert.DeserializeObject<List<ReceivableViewModel>>(stringJson,settings);
            return resultDes;
        }
    }
}
