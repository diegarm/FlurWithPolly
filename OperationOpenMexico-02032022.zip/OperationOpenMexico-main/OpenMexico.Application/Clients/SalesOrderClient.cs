﻿using Newtonsoft.Json;
using OpenMexico.Application.Clients;
using OpenMexico.Application.ViewModel;
using OpenMexico.Domain.Entities.SalesOrderList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OpenMexico.Application.Auth
{

    public class SalesOrderClient
    {
        private readonly HttpClient _httpClient;

        public SalesOrderClient(HttpClient httpClient)
        { 
            _httpClient = httpClient;
        }

        public async Task<List<SalesOrderViewModel>> GetSalesOrderAsync()
        {
            var result = await new AuthClient(_httpClient).Autheticate();

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.token);
            var response = await _httpClient.GetAsync("SalesOrderList?format=JSON&ViewMode=1");

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore
            };

            var stringJson = await response.Content.ReadAsStringAsync();
            var resultDes = JsonConvert.DeserializeObject<List<SalesOrderViewModel>>(stringJson,settings);
            return resultDes;
        }


    }



}
