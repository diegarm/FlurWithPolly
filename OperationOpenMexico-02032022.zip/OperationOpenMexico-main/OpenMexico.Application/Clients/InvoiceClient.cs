﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using OpenMexico.Application.Clients;
using OpenMexico.Application.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OpenMexico.Application.Auth
{

    public class InvoiceClient
    {
        private readonly HttpClient _httpClient;

        public InvoiceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<InvoiceViewModel>> GetInvoiceAsync()
        {
            var result = await new AuthClient(_httpClient).Autheticate();
            
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.token);
            var response = await _httpClient.GetAsync("InvoiceList?format=JSON&Detail=1");
            var stringJson = await response.Content.ReadAsStringAsync();
            Console.WriteLine("Json OK");

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore                
            };


            var resultDes = JsonConvert.DeserializeObject<List<InvoiceViewModel>>(stringJson,settings);
            Console.WriteLine("Conversão Invoice OK");
            return resultDes;
        }

    }
}
