﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.Auth
{
    public class LoginModel
    {
        [Required]
        [Display(Name = "username")]
        public string username { get; set; } = "API_BR";

        [DataType(DataType.Password)]
        [Display(Name = "md5password")]
        public string md5password { get; set; } = "821e33a6e2f22d473a1508d0d4b54381";
    }
}
