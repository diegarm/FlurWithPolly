﻿using Newtonsoft.Json;
using OpenMexico.Application.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Application.Clients
{
    public class BalanceClient
    {
        private readonly HttpClient _httpClient;

        public BalanceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<BalanceViewModel>> GetBalanceAsync()
        {
            var result = await new AuthClient(_httpClient).Autheticate();

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result.token);
            string dateNow = DateTime.Now.ToString("yyyy-MM-dd");
            string dateLastMonth = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-01");
            var response = await _httpClient.GetAsync($"BalanceByLabelsReport?format=JSON&Date_from_={dateLastMonth}&Date_to_={dateNow}");

            var settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore
            };

            var stringJson = await response.Content.ReadAsStringAsync();
            var resultDes = JsonConvert.DeserializeObject<List<BalanceViewModel>>(stringJson, settings);
            return resultDes;
        }
    }
}
