﻿using OpenMexico.Application.Auth;
using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;

namespace OpenMexico.Application.Clients
{
    public class AuthClient
    {
        private readonly HttpClient _httpClient;

        public AuthClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            
            if(_httpClient.BaseAddress == null)
                _httpClient.BaseAddress = new Uri("https://demant.oppen.io/report/");            
        }
        public  async Task<LoginResult> Autheticate()
        {
            var login = new LoginModel();

            Console.WriteLine("Authenticating...");
            var response = await _httpClient.PostAsJsonAsync<LoginModel>("authenticate", login);

            var reponseStream = await response.Content.ReadAsStreamAsync();
            Console.WriteLine("Authenticated");
            var loginResult = await JsonSerializer.DeserializeAsync<LoginResult>(reponseStream);


            return loginResult;
        }
    }
}
