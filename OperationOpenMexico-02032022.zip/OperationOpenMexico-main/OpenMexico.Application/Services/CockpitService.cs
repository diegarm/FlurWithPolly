﻿using AutoMapper;
using OpenMexico.Application.Auth;
using OpenMexico.Application.Clients;
using OpenMexico.Application.Interfaces;
using OpenMexico.Application.ViewModel;
using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using OpenMexico.Domain.Entities.SalesOrderList;
using OpenMexico.Domain.Interfaces;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace OpenMexico.Application.Services
{
    public class CockpitService : ICockpitService
    {
        private IInvoiceRepository _invoiceRepository;
        private IStockRepository _stockRepository;
        private ISalesOrderRepository _salesOrderRepository;
        private IReceivableRepository _receivableRepository;
        private IAnalyticsBalanceRepository _analyticsBalanceRepository;
        private IBalanceRepository _balanceRepository;
        private IPendingSalesRepository _pendingSalesRepository;
        private readonly IMapper _mapper;
        private readonly HttpClient _httpClient;

        public CockpitService(IInvoiceRepository invoiceRepository, IMapper mapper, HttpClient httpClient, IStockRepository stockRepository, ISalesOrderRepository salesOrderRepository, IReceivableRepository receivableRepository, IAnalyticsBalanceRepository analyticsBalanceRepository, IBalanceRepository balanceRepository, IPendingSalesRepository pendingSalesRepository)
        {
            _invoiceRepository = invoiceRepository;
            _mapper = mapper;
            _httpClient = httpClient;
            _stockRepository = stockRepository;
            _salesOrderRepository = salesOrderRepository;
            _receivableRepository = receivableRepository;
            _analyticsBalanceRepository = analyticsBalanceRepository;
            _balanceRepository = balanceRepository;
            _pendingSalesRepository = pendingSalesRepository;
        }

        public void Process()
        {
            try 
            {
                MainTask();
            }
            catch (Exception ex) { EventViewer(ex.ToString()); }
        }

        public void MainTask()
        {

            DateTime start = DateTime.Now;

            var parent = Task.Factory.StartNew(() =>
            {
                EventViewer("Main Task Started");

                Task.Factory.StartNew(() => { ProcessPendingSales001(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessBalance002(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessAnalyticalBalance003(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessReceivable004(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessSalesOrder005(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessStock006(); }, TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => { ProcessInvoice007(); }, TaskCreationOptions.AttachedToParent);
                
            });

            parent.Wait();
            EventViewer($"Main task completed in {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessPendingSales001()
        {

            DateTime start = DateTime.Now;
            EventViewer("Pending Sales loading");

            EventViewer("Authenticating...");
            var auth = new PendingSalesClient(_httpClient);

            EventViewer("Consulting the Pending Sales...");
            var list = auth.GetPendingSalesAsync().Result;

            EventViewer("Clearing...");
            _pendingSalesRepository.Clear();

            foreach (var itemModel in list)
            {
                var item = _mapper.Map<PendingSales>(itemModel);
                var result = _pendingSalesRepository.AddAsync<PendingSales>(item).Result;
            }

            EventViewer("Pending Sales finish ");
            EventViewer($"Pending Sales Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessBalance002()
        {
            DateTime start = DateTime.Now;
            EventViewer("Balance loading");

            EventViewer("Authenticating...");
            var auth = new BalanceClient(_httpClient);

            EventViewer("Consulting the Balance...");
            var list = auth.GetBalanceAsync().Result;

            EventViewer("Clearing...");
            _balanceRepository.Clear();

            foreach (var itemModel in list)
            {
                var item = _mapper.Map<Balance>(itemModel);
                var result = _balanceRepository.AddAsync<Balance>(item).Result;
            }

            EventViewer("Balance finish");
            EventViewer($"Balance Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessAnalyticalBalance003()
        {
            DateTime start = DateTime.Now;
            EventViewer("Analytics Analytics Balance loading");

            EventViewer("Authenticating...");
            var auth = new AnalyticsBalanceClient(_httpClient);

            EventViewer("Consult the Analytics Balance...");
            var list = auth.GetAnalyticalBalanceAsync().Result;

            EventViewer("Clearing...");
            _analyticsBalanceRepository.Clear();

            foreach (var itemModel in list)
            {
                var item = _mapper.Map<AnalyticalBalance>(itemModel);
                var result = _analyticsBalanceRepository.AddAsync<AnalyticalBalance>(item).Result;
            }

            EventViewer("Analytics Balance finish");
            EventViewer($"Analytics Balance Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessReceivable004()
        {
            DateTime start = DateTime.Now;
            EventViewer("Receivable loading");

            EventViewer("Authenticating...");
            var auth = new ReceivableClient(_httpClient);

            EventViewer("Consult the Receivable...");
            var list = auth.GetReceivablesAsync().Result;

            EventViewer("Clearing...");
            _receivableRepository.Clear();

            foreach (var itemModel in list)
            {
                var receivable = _mapper.Map<Receivable>(itemModel);
                var result = _receivableRepository.AddAsync<Receivable>(receivable).Result;
            }

            EventViewer("Receivable finish");
            EventViewer($"Receivable Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessSalesOrder005()
        {
            DateTime start = DateTime.Now;
            EventViewer("Sales Order loading");

            EventViewer("Authenticating...");
            var auth = new SalesOrderClient(_httpClient);

            EventViewer("Consult the Sales Order...");
            var list = auth.GetSalesOrderAsync().Result;

            EventViewer("Clearing...");
            _salesOrderRepository.Clear();

            foreach (var itemModel in list)
            {
                var salesOrder = _mapper.Map<SalesOrder>(itemModel);
                var result = _salesOrderRepository.AddAsync<SalesOrder>(salesOrder).Result;
            }

            EventViewer("Sales Order finish");
            EventViewer($"Sales Order Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");

        }

        private void ProcessStock006()
        {
            DateTime start = DateTime.Now;
            EventViewer("Stock loading");

            EventViewer("Authenticating...");
            var auth = new StockClient(_httpClient);

            EventViewer("Consult the stocks...");
            var list = auth.GetStockAsync().Result;

            EventViewer("Clearing...");
            _stockRepository.Clear();

            foreach (var itemModel in list)
            {
                var stock = _mapper.Map<StockList>(itemModel);
                var result = _stockRepository.AddAsync<StockList>(stock).Result;
            }

            EventViewer("Stock finish");
            EventViewer($"Stock Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        private void ProcessInvoice007()
        {
            DateTime start = DateTime.Now;
            EventViewer("Invoice loading");

            EventViewer("Authenticating...");
            var auth = new InvoiceClient(_httpClient);

            EventViewer("Consulting the invoices...");
            var list = auth.GetInvoiceAsync().Result;

            EventViewer("Clearing...");
            _invoiceRepository.Clear();

            foreach (var itemModel in list)
            {
                var invoice = _mapper.Map<Invoice>(itemModel);
                var result = _invoiceRepository.AddAsync<Invoice>(invoice).Result;
            }
            EventViewer("Invoice finish");
            EventViewer($"Invoice Finished in  {DateTime.Now.Subtract(start).TotalSeconds} seconds and {DateTime.Now.Subtract(start).TotalMinutes} minutes");
        }

        public void ProcessCyclic(int timeSeconds)
        {
            EventViewer("Ciclyc process started");
            Task.Run(() => Start(timeSeconds));            
        }

        private Task Start(int timeSeconds)
        {
            while (true)
            {
                Process();

                string msg = $"Ciclyc process in paused (Waiting {timeSeconds.ToString()} seconds ({DateTime.Now.ToString()})";

                EventViewer(msg);
                Thread.Sleep(timeSeconds * 1000);
            }
        }

        private static void EventViewer(string eventMessage, bool isError = false)
        {
            Console.WriteLine(eventMessage);
            //EventLog.WriteEntry("OpenMexico", eventMessage);

            if (isError)
                EventLog.WriteEntry("OpenMexico", eventMessage, EventLogEntryType.Error);
        }
    }
}
