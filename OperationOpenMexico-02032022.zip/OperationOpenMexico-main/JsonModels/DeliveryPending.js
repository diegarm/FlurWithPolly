[{
    "Pedido": 20000003994,
    "Fecha Entrega": "10/01/2022",
    "subrows": [{
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro Itera II 410340",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9003",
        "Nombre": "Mantenimiento preventivo y calibración Timpanómetro Titan SN0945334",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9011",
        "Nombre": "Mantenimiento Correctivo y calibración GSI AI061921",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9011",
        "Nombre": "Mantenimiento Correctivo VisualEyes ",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Maico MA90553818",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Maico MA9043855",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Maico 72904",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Maico 72908",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  AD629 SN0934150",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Itera II 410341",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro Itera II 410339",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  AD629 SN0944355",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9011",
        "Nombre": "Mantenimiento Correctivo y calibración de audiómetro Madsen ",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  AD629 SN0944357",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9017",
        "Nombre": "Mantenimiento preventivo y calibración de audiómetro  Itera II 410342",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9005",
        "Nombre": "Calibración OAE Otoport SN803053",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "9003",
        "Nombre": "Mantenimiento preventivo y calibración Timpanómetro GSI SNALO61928",
        "Unidad": "UNSERV",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8517466",
        "Nombre": "OtoAccess Database",
        "Unidad": "PZA",
        "Cant.": "4.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "21.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004245,
    "Fecha Entrega": "26/01/2022",
    "subrows": [{
        "Artículo": "8520390",
        "Nombre": "Eyeseecam VHIT + Dell + Otoaccess",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8517470",
        "Nombre": "Otoaccess",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "8530971",
        "Nombre": "VisualEyes EyeSeeCam vHIT + Laptop + OtoAccess",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8511935",
        "Nombre": "Visual Eyes 505B S",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8517237",
        "Nombre": "VORTEQ option",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8104337",
        "Nombre": "Tape measure 3M",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8503442",
        "Nombre": "Headband 2013 Vorteq/VHIT",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "8524545",
        "Nombre": "VisualEyes & Vorteq Asmt Vorteq Diag+Asmt+Lic.Only",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "8.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004691,
    "Fecha Entrega": "17/02/2022",
    "subrows": [{
        "Artículo": "149281",
        "Nombre": "\"Speaker Unit, 2L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004787,
    "Fecha Entrega": "23/02/2022",
    "subrows": [{
        "Artículo": "8517379",
        "Nombre": "RE-7 Headband with 2 yokes black",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004829,
    "Fecha Entrega": "24/02/2022",
    "subrows": [{
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }]
}, {
    "Pedido": 20000004864,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "226530",
        "Nombre": "\"Shell, Set Top Minirite T RC Tp Dpb Led\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "149282",
        "Nombre": "\"Speaker Unit , 2R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.00"
    }, {
        "Artículo": "206885",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "0.10"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "5.00",
        "Pendiente a Entregar": "0.10"
    }]
}, {
    "Pedido": 20000004865,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "6.00",
        "Pendiente a Entregar": "6.00"
    }]
}, {
    "Pedido": 20000004873,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "6.00",
        "Pendiente a Entregar": "6.00"
    }]
}, {
    "Pedido": 20000004874,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "222316",
        "Nombre": "Hearlink 9030 Mnr T R Dg",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149292",
        "Nombre": "\"Speaker Unit, 3R 100 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149291",
        "Nombre": "\"Speaker Unit, 3L 100 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "6.00",
        "Pendiente a Entregar": "6.00"
    }]
}, {
    "Pedido": 20000004876,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "6.00",
        "Pendiente a Entregar": "6.00"
    }]
}, {
    "Pedido": 20000004882,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004884,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "M52378",
        "Nombre": "\"Teddy Bear, Bahs\"",
        "Unidad": "PZA",
        "Cant.": "24.00",
        "Pendiente a Entregar": "24.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "24.00",
        "Pendiente a Entregar": "24.00"
    }]
}, {
    "Pedido": 20000004890,
    "Fecha Entrega": "28/02/2022",
    "subrows": [{
        "Artículo": "149307",
        "Nombre": "Dome Set Bass Double 8Mm Minifit",
        "Unidad": "PZA",
        "Cant.": "5.00",
        "Pendiente a Entregar": "5.00"
    }, {
        "Artículo": "149308",
        "Nombre": "Dome Set Bass Double 10Mm Minifit",
        "Unidad": "PZA",
        "Cant.": "5.00",
        "Pendiente a Entregar": "5.00"
    }, {
        "Artículo": "130091",
        "Nombre": "\"WAX PROTECTION SET, PROWAX\"",
        "Unidad": "PZA",
        "Cant.": "30.00",
        "Pendiente a Entregar": "30.00"
    }, {
        "Artículo": "123459",
        "Nombre": "Prowax-System",
        "Unidad": "PZA",
        "Cant.": "10.00",
        "Pendiente a Entregar": "10.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "50.00",
        "Pendiente a Entregar": "50.00"
    }]
}, {
    "Pedido": 20000004911,
    "Fecha Entrega": "01/03/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "222316",
        "Nombre": "Hearlink 9030 Mnr T R Dg",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "149275",
        "Nombre": "\"Speaker Unit, 3R 60 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149276",
        "Nombre": "\"Speaker Unit, 3L 60 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "12.00",
        "Pendiente a Entregar": "12.00"
    }]
}, {
    "Pedido": 20000004913,
    "Fecha Entrega": "01/03/2022",
    "subrows": [{
        "Artículo": "222312",
        "Nombre": "Hearlink 9030 Mnr T R Be",
        "Unidad": "PZA",
        "Cant.": "2.00",
        "Pendiente a Entregar": "2.00"
    }, {
        "Artículo": "200299",
        "Nombre": "\"Charger, Minirite T R 40\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "149283",
        "Nombre": "\"Speaker Unit, 3L 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "206885-N",
        "Nombre": "Philips Branded Shopper",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "6.00",
        "Pendiente a Entregar": "6.00"
    }]
}, {
    "Pedido": 20000004918,
    "Fecha Entrega": "01/03/2022",
    "subrows": [{
        "Artículo": "149284",
        "Nombre": "\"Speaker Unit, 3R 85 Minifit\"",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }]
}, {
    "Pedido": 20000004925,
    "Fecha Entrega": "02/03/2022",
    "subrows": [{
        "Artículo": "90004",
        "Nombre": "Soporte para Pantalla",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "8511935",
        "Nombre": "Visual Eyes 505B S",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "90002",
        "Nombre": "Laptop Dell",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "8525513",
        "Nombre": "Upgrade VE505 3.0 to VE525 3.0 +Lic.Only",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "4.00",
        "Pendiente a Entregar": "4.00"
    }]
}, {
    "Pedido": 20000004926,
    "Fecha Entrega": "02/03/2022",
    "subrows": [{
        "Artículo": "8010840",
        "Nombre": "Diadema HB7 RadioEar con 2 yugos",
        "Unidad": "PZA",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }, {
        "Artículo": "Totales",
        "Nombre": "",
        "Unidad": "",
        "Cant.": "1.00",
        "Pendiente a Entregar": "1.00"
    }]
}]