﻿using Microsoft.EntityFrameworkCore;
using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using OpenMexico.Domain.Interfaces;
using OpenMexico.Infrastructure.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Infrastructure.Data.Repository
{
    public class InvoiceRepository : GeneralRepository, IInvoiceRepository
    {

        public InvoiceRepository(OpenMexicoContext _context)
        {
            base.context = _context;
        }

        public override void Clear()
        {
            context.Database.ExecuteSqlRaw("DELETE FROM INVOICEITEM");
            context.Database.ExecuteSqlRaw("DELETE FROM INVOICE");
        }


    }
}
