﻿using Microsoft.EntityFrameworkCore;
using OpenMexico.Domain.Interfaces;
using OpenMexico.Infrastructure.Data.Context;
using System.Threading.Tasks;

namespace OpenMexico.Infrastructure.Data.Repository
{
    public abstract class GeneralRepository : IGeneralRepository
    {
        public OpenMexicoContext context;

        public async Task<bool> AddAsync<T>(T entity) where T : class
        {
            context.Add(entity);
            return await SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync<T>(T entity) where T : class
        {
            context.Update(entity);
            return await SaveChangesAsync();

        }

        public async Task<bool> DeleteAsync<T>(T entity) where T : class
        {
            context.Remove(entity);
            return await SaveChangesAsync();
        }

      
        public async Task<bool> SaveChangesAsync()
        {
            return (await context.SaveChangesAsync()) > 0;
        }

        public abstract void Clear();
    }
}
