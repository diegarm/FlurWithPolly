﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace OpenMexico.Infrastructure.Data.Migrations
{
    public partial class Initi : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ANALYTICALBALANCE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cuenta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SaldoInicial = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    DebeMovimientos = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    HaberMovimientos = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    DebeAcumulado = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    HaberAcumulado = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Saldo = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ANALYTICALBALANCE", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BALANCE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Etiqueta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BALANCE", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "INVOICE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nro = table.Column<long>(type: "bigint", nullable: false),
                    NroFolioFactura = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TipodeFactura = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechaTrans = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaFactura = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaVto = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Cliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NombredelCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Vendedor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Sucursal = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Moneda = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IVA = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Impuestos = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    SubTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RegistrodeOrigen = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaUltActualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Computadora = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Departamento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TipoFormulario = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Aprobado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Referencia = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Etiquetas = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Idioma = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Turno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TurnoNro = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Invalido = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Usuario = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Impresoa = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TasadeCambio = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Pais = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Municipio = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CodigoPostal = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GrupodeVenta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CostoTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CentrodeCostodeCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AcuerdodeDescuentos = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FormadeEntrega = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TipoOperacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TerminosdeEntrega = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContactodeEntrega = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FacturaInterna = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TerminosdePago = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Garantes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AcuerdodePrecios = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActualizaStock = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Contacto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechaServicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Clausulas = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comentario = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FacturaenGrupo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepositodeStock = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Campana = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CuotasManuales = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cuestionada = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CategoriadeFactura = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RegimenFiscal = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TipodeComprobante = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ValidadoElectrónicamente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Fecha2doVto = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FormadeCancelacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechayHoraCertificacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechayHoradeEmision = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TXTGenerado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UsodelCFDI = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TipodeRelacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InvalidadoElectronicamente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comercioexterior = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClavedePedimento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CertificadodeOrigen = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Incoterm = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Subdivision = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VendedorCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GrupodeClientesCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SegmentodeMercadoCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CodigoSucursal = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INVOICE", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PENDINGSALES",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pedido = table.Column<long>(type: "bigint", nullable: false),
                    FechaEntrega = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PENDINGSALES", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RECEIVABLE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Vencido = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Saldo = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RECEIVABLE", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SALESORDER",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nro = table.Column<long>(type: "bigint", nullable: false),
                    NroOrdenCompraCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaUltActualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Cliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NombredelCliente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Moneda = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SubTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Vendedor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Departamento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Aprobado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GrupodeVenta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cerrado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Facturado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Entregado = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SALESORDER", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "STOCKLIST",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Articulo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Grupo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Subgrupo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Posicion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NroSerie = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DepositodeStock = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Unidad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Stock = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    NroPedimento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Lote = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_STOCKLIST", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BALANCEITEMS",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    balanceId = table.Column<int>(type: "int", nullable: true),
                    Cuenta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Monto = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BALANCEITEMS", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BALANCEITEMS_BALANCE_balanceId",
                        column: x => x.balanceId,
                        principalTable: "BALANCE",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "INVOICEITEM",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    invoiceId = table.Column<int>(type: "int", nullable: true),
                    CodArticulo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cant = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Precio = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Descuento = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    NetoFila = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TotalFila = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Costo = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CostoOperativo = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CostOpTotal = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Ganancia = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PorcGanancia = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INVOICEITEM", x => x.Id);
                    table.ForeignKey(
                        name: "FK_INVOICEITEM_INVOICE_invoiceId",
                        column: x => x.invoiceId,
                        principalTable: "INVOICE",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PENDINGSALESITEMS",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pendingSalesId = table.Column<int>(type: "int", nullable: true),
                    Articulo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Unidad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cant = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PendienteaEntregar = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PENDINGSALESITEMS", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PENDINGSALESITEMS_PENDINGSALES_pendingSalesId",
                        column: x => x.pendingSalesId,
                        principalTable: "PENDINGSALES",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SALDORECEIVABLE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ReceivableId = table.Column<int>(type: "int", nullable: true),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nro = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechaFactura = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaVto = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Dias = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Moneda = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Saldo = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Acum = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Vendedor = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SALDORECEIVABLE", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SALDORECEIVABLE_RECEIVABLE_ReceivableId",
                        column: x => x.ReceivableId,
                        principalTable: "RECEIVABLE",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SALESORDERITEM",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    salesId = table.Column<int>(type: "int", nullable: true),
                    Articulo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cant = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Unidad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Precio = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Neto = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SALESORDERITEM", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SALESORDERITEM_SALESORDER_salesId",
                        column: x => x.salesId,
                        principalTable: "SALESORDER",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BALANCEITEMS_balanceId",
                table: "BALANCEITEMS",
                column: "balanceId");

            migrationBuilder.CreateIndex(
                name: "IX_INVOICEITEM_invoiceId",
                table: "INVOICEITEM",
                column: "invoiceId");

            migrationBuilder.CreateIndex(
                name: "IX_PENDINGSALESITEMS_pendingSalesId",
                table: "PENDINGSALESITEMS",
                column: "pendingSalesId");

            migrationBuilder.CreateIndex(
                name: "IX_SALDORECEIVABLE_ReceivableId",
                table: "SALDORECEIVABLE",
                column: "ReceivableId");

            migrationBuilder.CreateIndex(
                name: "IX_SALESORDERITEM_salesId",
                table: "SALESORDERITEM",
                column: "salesId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ANALYTICALBALANCE");

            migrationBuilder.DropTable(
                name: "BALANCEITEMS");

            migrationBuilder.DropTable(
                name: "INVOICEITEM");

            migrationBuilder.DropTable(
                name: "PENDINGSALESITEMS");

            migrationBuilder.DropTable(
                name: "SALDORECEIVABLE");

            migrationBuilder.DropTable(
                name: "SALESORDERITEM");

            migrationBuilder.DropTable(
                name: "STOCKLIST");

            migrationBuilder.DropTable(
                name: "BALANCE");

            migrationBuilder.DropTable(
                name: "INVOICE");

            migrationBuilder.DropTable(
                name: "PENDINGSALES");

            migrationBuilder.DropTable(
                name: "RECEIVABLE");

            migrationBuilder.DropTable(
                name: "SALESORDER");
        }
    }
}
