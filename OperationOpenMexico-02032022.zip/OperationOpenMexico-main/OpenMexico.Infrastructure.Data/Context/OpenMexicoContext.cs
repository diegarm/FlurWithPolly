﻿using Microsoft.EntityFrameworkCore;
using OpenMexico.Domain.Entities;
using OpenMexico.Domain.Entities.InvoiceList;
using OpenMexico.Domain.Entities.SalesOrderList;
using OpenMexico.Infrastructure.Data.Configuration;

namespace OpenMexico.Infrastructure.Data.Context
{
    public class OpenMexicoContext : DbContext
    {


        public DbSet<StockList> Stock { get; set; }
        public DbSet<Invoice> Invoice { get; set; }
        public DbSet<InvoiceItem> InvoiceItem { get; set; }
        public DbSet<SaldoReceivable> SaldoReceivable { get; set; }
        public DbSet<Receivable> Receivable { get; set; }
        public DbSet<SalesOrder> SalesOrder { get; set; }
        public DbSet<AnalyticalBalance> AnalyticalBalance { get; set; }

        public DbSet<Balance> Balance { get; set; }
        public DbSet<BalanceItems> BalanceItems { get; set; }


        public DbSet<PendingSales> PendingSales { get; set; }
        public DbSet<PendingSalesItems> PendingSalesItems { get; set; }

        public OpenMexicoContext(DbContextOptions<OpenMexicoContext> options) : base(options)
        {
         

        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(OpenMexicoContext).Assembly);
            base.OnModelCreating(modelBuilder);

        }
    }
}
