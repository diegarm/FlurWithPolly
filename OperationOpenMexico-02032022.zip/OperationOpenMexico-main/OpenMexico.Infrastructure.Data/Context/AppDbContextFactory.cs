﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenMexico.Infrastructure.Data.Context
{
    public class AppDbContextFactory : IDesignTimeDbContextFactory<OpenMexicoContext>
    {
        public OpenMexicoContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json")
               .Build();

            var optionsBuilder = new DbContextOptionsBuilder<OpenMexicoContext>();
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("DataBaseOpenMexico"));
            var context = new OpenMexicoContext(optionsBuilder.Options);

           

            return context;
        }
    }
}
