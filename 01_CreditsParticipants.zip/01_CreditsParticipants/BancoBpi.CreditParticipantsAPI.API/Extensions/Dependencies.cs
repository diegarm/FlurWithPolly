using BancoBpi.CreditParticipantsAPI.Application.BusinessCase;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.BusinessCase;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.Repository;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Repository;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data.Interfaces;
using Microsoft.Extensions.DependencyInjection;


namespace BancoBpi.CreditParticipantsAPI.API.Extensions
{
    /// <summary>
    /// Class for developer change
    /// </summary>
    public static class Dependencies
    {
        public static void AddPluggableDependency(this IServiceCollection services)
        {
            services.AddScoped<IParticipantService, ParticipantService>();
            services.AddScoped<IParticipantDomainRepository, ParticipantDomainRepository>();
            services.AddScoped<IParticipantDataRepository, ParticipantDataRepository>();

        }

    }
}

