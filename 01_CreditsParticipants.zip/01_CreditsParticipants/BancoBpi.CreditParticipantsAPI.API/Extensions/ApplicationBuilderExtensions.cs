using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.StaticFiles;

namespace BancoBpi.CreditParticipantsAPI.Api.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        static readonly string API_CONTRACT_FILE = "../contract/openapi.yaml";

#warning You should replace api name
        static readonly string API_TITLE = "CreditParticipantsAPI";

        public static void UseReDocConfig(this IApplicationBuilder app)
        {
            app.UseReDoc(options =>
            {
                options.DocumentTitle = API_TITLE;
                options.SpecUrl = API_CONTRACT_FILE;
            });
        }

        public static void EnableStaticFiles(this IApplicationBuilder app)
        {
            app.UseDefaultFiles();
            var provider = new FileExtensionContentTypeProvider();
            provider.Mappings[".yaml"] = "text/yaml";
            provider.Mappings[".map"] = "application/json";
            provider.Mappings[".js.map"] = "application/json";
            app.UseStaticFiles(new StaticFileOptions
            {
                ContentTypeProvider = provider
            });
        }

    }
}

