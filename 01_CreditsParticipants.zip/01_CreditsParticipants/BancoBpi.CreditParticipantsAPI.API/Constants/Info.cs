﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.API.Constants
{
    public static class Info
    {
        public static string INFO_RESSOURCE_NAME = "Self";
    }
}
