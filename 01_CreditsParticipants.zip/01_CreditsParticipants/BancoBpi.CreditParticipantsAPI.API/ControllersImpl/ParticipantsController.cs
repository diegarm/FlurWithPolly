﻿using AutoMapper;
using BancoBpi.CreditParticipantsAPI.API.Constants;
using BancoBpi.CreditParticipantsAPI.API.Validation;
using BancoBpi.CreditParticipantsAPI.APIDomain.Controllers;
using BancoBpi.CreditParticipantsAPI.APIDomain.Models;
using BancoBpi.CreditParticipantsAPI.Domain.Command;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.BusinessCase;
using BancoBpi.Pluggable.API.Exceptions;
using BancoBpi.Pluggable.API.Hateoas;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.API.ControllersImpl
{
    public class ParticipantsController : ParticipantApiController
    {
        private readonly IMapper _mapper;
        private readonly ILogger<ParticipantsController> _logger;
        private readonly IKindGenerator _kindGenerator;
        private readonly IHateoasGenerator _hateoasGenerator;
        private readonly IParticipantService _service;

        public ParticipantsController(IMapper mapper, ILogger<ParticipantsController> logger, IHateoasGenerator hateoasGenerator, IParticipantService service, IKindGenerator kindGenerator)
        {
            _mapper = mapper;
            _logger = logger;
            _hateoasGenerator = hateoasGenerator;
            _service = service;
            _kindGenerator = kindGenerator;
        }

        public override async Task<IActionResult> GetIndividualsId([FromRoute(Name = "id"), MinLength(1), Required] string id)
        {
            IndividualParticipantOutputDetailed result = null;

            _logger.LogDebug("Start of method GetIndividualsId");

            try
            {
                _logger.LogDebug("Guid Validation");
                if (!Guid.TryParse(id, out Guid guid))
                    throw new BadRequestException(ValidationMessages.ERROR_GUID_INVALID_DETAIL);


                _logger.LogDebug("Searching Participant");
                var participant = await _service.FindParticipant(id).ConfigureAwait(false);

                _logger.LogDebug("Mapping Participant");
                result = _mapper.Map<ParticipantDomain, IndividualParticipantOutputDetailed>(participant);

                _logger.LogDebug("Generating the Kind");
                result.Kind = _kindGenerator.Make();

                _logger.LogDebug("Generating the Hateoas");
                var link = _hateoasGenerator.Make($"individuals/{result.Id}");
                result.Links = _hateoasGenerator.MakeLinks<CreditModelsAndUseCasesCommonBodyLinks>(Info.INFO_RESSOURCE_NAME, link);

                _logger.LogDebug("Finish of method PostIndividuals");


            }
            catch (BadRequestException ex)
            {
                throw new PluggableException(ex, ValidationMessages.ERROR_GUID_INVALID, 400);
            }
            catch (NotFoundException ex)
            {
                throw new PluggableException(ex, ValidationMessages.PARTICIPANT_NOT_FOUND_MESSAGE, 404);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetIndividualsId", ex);
                throw new PluggableException(ex, ValidationMessages.SERVER_ERROR_MESSAGE, 500);
            }

            return Ok(result);
        }

        public override async Task<IActionResult> PostIndividuals([FromBody] IndividualParticipantInput individualParticipantInput)
        {
            IndividualParticipantOutputDetailed result = null;

            try
            {
                _logger.LogDebug("Start of method PostIndividuals");

                var model = _mapper.Map<ParticipantCommand>(individualParticipantInput);

                var participant = await _service.CreateParticipant(model).ConfigureAwait(false);
                     

                
                result = _mapper.Map<IndividualParticipantOutputDetailed>(participant);
                result.Kind = _kindGenerator.Make();

                var link = _hateoasGenerator.Make($"individuals/{result.Id}");
                result.Links = _hateoasGenerator.MakeLinks<CreditModelsAndUseCasesCommonBodyLinks>(Info.INFO_RESSOURCE_NAME, link);
                
                _logger.LogDebug("Finish of method PostIndividuals");

            }
            catch (ValidationException ex)
            {
                throw new PluggableException(ex, "Invalid participant input data", 400);
            }
            catch (BadRequestException ex)
            {
                throw new PluggableException(ex, "Invalid participant input data", 400);
            }
            catch (Exception ex)
            {
                _logger.LogError("PostIndividuals", ex);
                throw new PluggableException(ex, ValidationMessages.SERVER_ERROR_MESSAGE, 500);
            }

            return Ok(result);


        }

        public override async Task<IActionResult> PutIndividualsId([FromRoute(Name = "id"), MinLength(1), Required] string id, [FromBody] IndividualParticipantOutputDetailed individualParticipantOutputDetailed)
        {
            IndividualParticipantOutputDetailed result = null;

            _logger.LogDebug("Start of method PutIndividualsId");

            try
            {
                _logger.LogDebug("Guid Validation");
                if (!Guid.TryParse(id, out Guid idGuid))
                    throw new BadRequestException(ValidationMessages.ERROR_GUID_INVALID_DETAIL);

                individualParticipantOutputDetailed.Id = idGuid.ToString();

                _logger.LogDebug("Mapping Participant Command");
                var input = _mapper.Map<UpdateParticipantCommand>(individualParticipantOutputDetailed);

                _logger.LogDebug("Searching Participant");
                var participant = await _service.UpdateParticipant(input).ConfigureAwait(false);


                _logger.LogDebug("Mapping IndividualParticipantOutputDetailed");
                result = _mapper.Map<IndividualParticipantOutputDetailed>(participant);

                _logger.LogDebug("Generating the Kind");
                result.Kind = _kindGenerator.Make();

                _logger.LogDebug("Generating the Hateoas");
                var link = _hateoasGenerator.Make($"individuals/{result.Id}");
                result.Links = _hateoasGenerator.MakeLinks<CreditModelsAndUseCasesCommonBodyLinks>(Info.INFO_RESSOURCE_NAME, link);

                _logger.LogDebug("Finish of method PutIndividualsId");

            }
            catch (BadRequestException ex)
            {
                throw new PluggableException(ex, ValidationMessages.ERROR_GUID_INVALID, 400);
            }
            catch (NotFoundException ex)
            {
                throw new PluggableException(ex, ValidationMessages.PARTICIPANT_NOT_FOUND_MESSAGE, 404);
            }
            catch (Exception ex)
            {
                _logger.LogError("PutIndividualsId", ex);
                throw new PluggableException(ex, ValidationMessages.SERVER_ERROR_MESSAGE, 500);
            }

            return Ok(result);
        }
    }
}
