using AutoMapper;
using BancoBpi.CreditParticipantsAPI.APIDomain.Models;
using BancoBpi.CreditParticipantsAPI.Domain.Command;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;

namespace BancoBpi.CreditParticipantsAPI.API.Mappings
{
    /// <summary>
    /// This class contains AutoMapper definitions
    /// 
    /// Example: 
    ///     CreateMap<OriginType, DestinyType>().ReverseMap;
    ///     
    /// Product documentation: https://automapper.org/
    /// 
    /// Reference use: https://bancobpi.stoplight.org/doc/qualquercoisa
    /// 
    /// </summary>
    public class GeneralProfileAPI : Profile
    {
        public GeneralProfileAPI()
        {
            CreateMap<IndividualParticipantInput, ParticipantCommand>().ReverseMap();
            CreateMap<IndividualParticipantOutputDetailed, UpdateParticipantCommand>().ReverseMap();
            CreateMap<IndividualParticipantOutputDetailed, ParticipantDomain>().ReverseMap();
        }
    }
}

