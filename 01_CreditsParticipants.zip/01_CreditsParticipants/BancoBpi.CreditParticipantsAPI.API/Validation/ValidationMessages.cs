﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.API.Validation
{
    public class ValidationMessages
    {
        public static string PARTICIPANT_NOT_FOUND_MESSAGE = "Participant ID not found";
        public static string SERVER_ERROR_MESSAGE = "Internal Server Error";
        public static string ERROR_OBTAIN_KIND = " Error obtain Kind";
        public static string ERROR_OBTAIN_LINKS = " Error obtain Links";
        public static string ERROR_AUTOMAPPER = "Error automapper";
        public static string ERROR_RETURN_LINKS = "Error return links";
        public static string ERROR_GUID_INVALID = "Invalid Guid";
        public static string ERROR_GUID_INVALID_DETAIL = "Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).";

    }
}
