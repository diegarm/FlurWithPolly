using BancoBpi.CreditParticipantsAPI.Api.Extensions;
using BancoBpi.CreditParticipantsAPI.API.Extensions;
using BancoBpi.Infrastructure.EntityFramework.Enum;
using BancoBpi.Infrastructure.EntityFramework.Extensions;
using BancoBpi.Pluggable.API.Extensions;
using BancoBpi.Pluggable.API.Hateoas.Extension;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Converters;
using System.Reflection;

namespace BancoBpi.CreditParticipantsAPI.Api
{
    /// <summary>
    /// You should not change this class
    /// 
    /// Do you realy need it?!?!?!
    /// 
    /// </summary>
    public class Startup
    {
        public IConfiguration Configuration { get; }
        private readonly IWebHostEnvironment WebHostEnvironment;

        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(webHostEnvironment.ContentRootPath)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile(@$"Config\appsettings.{webHostEnvironment.EnvironmentName}.json", optional: true)
            .AddEnvironmentVariables();

            Configuration = builder.Build();
            WebHostEnvironment = webHostEnvironment;
        }

        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers().AddNewtonsoftJson(options =>
                    options.SerializerSettings.Converters.Add(new StringEnumConverter())
            );

            services.AddPluggableCore(WebHostEnvironment, Configuration);

            services.AddPluggableDependency();

            services.AddDataBase(Configuration, Provider.PostgreSQL, "Default");
            
            //This method auto configure the AutoMapper classes. (You don't need to change this setting)
            services.AddAutoMapperConfiguration(Assembly.GetExecutingAssembly());
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            

            app.UsePluggableCore();

            app.UseReDocConfig();

            app.EnableStaticFiles();

            app.UseDefaultFiles();

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}

