using AutoMapper;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Entities;

namespace BancoBpi.CreditParticipantsAPI.Domain.Mappings
{
    /// <summary>
    /// This class contains AutoMapper definitions
    /// 
    /// Example: 
    ///     CreateMap<OriginType, DestinyType>().ReverseMap;
    ///     
    /// Product documentation: https://automapper.org/
    /// 
    /// </summary>
    public class GeneralProfileData : Profile
    {
        public GeneralProfileData()
        {
            CreateMap<T_APICreditoParticipante, ParticipantDomain>().ReverseMap();

        }
    }
}

