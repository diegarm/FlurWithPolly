﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Infrastructure.Entities
{
    [Table("T_APICreditoParticipante")]
    public class T_APICreditoParticipante
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string id { get; set; }

        [Column("dados")]
        public string Data { get; set; }

        [Column("datainclusao")]
        public DateTime DateCreated { get; set; }

        [Column("dataalteracao")]
        public DateTime DateModified { get; set; }

        [Column("inseridopor")]
        [StringLength(50)]
        public string CreatedBy { get; set; }

        [Column("alteradopor")]
        [StringLength(50)]
        public string ModifiedBy { get; set; }

    }
}
