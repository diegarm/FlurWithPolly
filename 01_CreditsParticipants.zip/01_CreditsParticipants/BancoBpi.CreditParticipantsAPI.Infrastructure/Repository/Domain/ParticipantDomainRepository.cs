﻿using AutoMapper;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.Repository;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Entities;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.Json;
using BancoBpi.Pluggable.API.Tools;

namespace BancoBpi.CreditParticipantsAPI.Infrastructure.Repository
{
    public class ParticipantDomainRepository : IParticipantDomainRepository
    {

        private readonly IMapper _mapper;
        private readonly IParticipantDataRepository _personRepository;
        private readonly ILogger<ParticipantDomainRepository> _logger;
        private readonly Pluggable.API.Domain.IContextInfo _contextInfo;

        public ParticipantDomainRepository(IMapper mapper, IParticipantDataRepository personRepository, ILogger<ParticipantDomainRepository> logger, Pluggable.API.Domain.IContextInfo contextInfo)
        {
            _mapper = mapper;
            _personRepository = personRepository;
            _logger = logger;
            _contextInfo = contextInfo;
        }

        public async Task<ParticipantDomain> GetByIdAsync(object id)
        {
            ParticipantDomain participantDomain = null;
            try
            {
                var participant = await _personRepository.Get(id).ConfigureAwait(false);

                if (!String.IsNullOrEmpty(participant?.Data))
                    participantDomain = JsonSerializer.Deserialize<ParticipantDomain>(participant.Data);

            }
            catch (Exception ex)
            {
                _logger.LogError("GetByIdAsync", ex);
                throw;
            }

            return participantDomain;
        }


        public async Task<ParticipantDomain> CreateAsync(ParticipantDomain participant)
        {
            participant.Id = Guid.NewGuid().ToString();

            var input = new T_APICreditoParticipante()
            {
                id = participant.Id,
                DateCreated = DateTime.Now,
                DateModified = DateTime.Now,
                CreatedBy = _contextInfo.ClientID,
                Data = JsonSerializer.Serialize(participant)
            };


            using (var transaction = await _personRepository.CreateTransaction())
            {
                try
                {

                    var result = await _personRepository.Insert(input);
                    await transaction.CommitAsync();
                    return participant;

                }
                catch (Exception ex)
                {
                    _logger.LogError("Error saving participant in Database", ex);
                    throw;
                }
            }

        }

        public async Task<ParticipantDomain> UpdateAsync(ParticipantDomain participantDomain)
        {

            try
            {
                var participant = await _personRepository.Get(participantDomain.Id);
                    
                if(participant is not null)
                {
                    participant.DateModified = DateTime.Now;
                    participant.Data = participantDomain.ToJson();
                    participant.ModifiedBy = _contextInfo.ClientID;

                    await _personRepository.Update(participant);

                    participantDomain = participant.Data.FromJson<ParticipantDomain>();
                }

                return participantDomain;

            }
            catch (Exception ex)
            {
                _logger.LogError("UpdateAsync", ex);
                throw;
            }            
        }
    }
}
