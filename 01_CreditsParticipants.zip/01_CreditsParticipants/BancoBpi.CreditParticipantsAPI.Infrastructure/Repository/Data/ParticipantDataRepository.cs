﻿using BancoBpi.CreditParticipantsAPI.Infrastructure.Entities;
using BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data.Interfaces;
using BancoBpi.Infrastructure.EntityFramework.Context;
using BancoBpi.Infrastructure.EntityFramework.Repository;

namespace BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data
{
    public class ParticipantDataRepository : UnitOfWork<T_APICreditoParticipante>, IParticipantDataRepository
    {
        public ParticipantDataRepository(ApplicationContext context): base(context, typeof(ParticipantDataRepository))
        {

        }
    }
}
