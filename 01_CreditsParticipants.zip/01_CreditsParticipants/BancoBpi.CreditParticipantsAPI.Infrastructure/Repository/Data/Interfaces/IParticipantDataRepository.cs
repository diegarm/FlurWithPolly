﻿using BancoBpi.CreditParticipantsAPI.Infrastructure.Entities;
using BancoBpi.Infrastructure.EntityFramework.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Infrastructure.Repository.Data.Interfaces
{
    public interface IParticipantDataRepository : IRepository<T_APICreditoParticipante>
    {
    }
}
