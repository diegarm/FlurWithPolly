﻿using BancoBpi.OpenTelemetry.Extensions.Constants;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OpenTelemetry;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace BancoBpi.OpenTelemetry.Extensions.Exporters
{
    class SerilogLogExporter : BaseExporter<Activity>
    {

        private readonly Microsoft.Extensions.Logging.ILogger _logger;
        private readonly Dictionary<string, double> contextDictionary;
        private readonly string _serviceId;


        public SerilogLogExporter(IConfiguration configuration)
        {
            _logger = new LoggerFactory().AddSerilog(new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger()).CreateLogger(typeof(SerilogLogExporter));
            _serviceId = configuration["Serilog:Properties:Application"];
            contextDictionary = new Dictionary<string, double>();
        }


        public override ExportResult Export(in Batch<Activity> batch)
        {

            foreach (var activity in batch)
            {
                string responseStatus;
                string xRequestId = activity.Baggage.FirstOrDefault(b => b.Key == ActivityConstants.HEADER_X_REQUEST_ID).Value;
                Int32.TryParse(activity.Baggage.FirstOrDefault(b => b.Key == ActivityConstants.SERVICE_CURRENT_DEPTH).Value, out int serviceCurrentDepth);
                string error = activity.Tags.FirstOrDefault(b => b.Key == "otel.status_code").Value;
                responseStatus = error.ToLower().Equals("error") ? error : "OK";

                string key = activity.TraceId.ToString();
                //_logger.LogDebug($"{activity.Kind.ToString()} {activity.OperationName} {activity.DisplayName}");
                if (activity.Kind == ActivityKind.Client)
                {
                    var clientId = (string)activity.TagObjects.FirstOrDefault(b => b.Key == "http.url").Value;
                    double totalClientTime = contextDictionary.GetValueOrDefault(key) + activity.Duration.TotalMilliseconds;
                    contextDictionary[key] = totalClientTime;

                    _logger.LogInformation("{Service.Id} {Service.CurrentDepth} {x-request-id} {Client.Id} {Client.Url}  {Client.TimeTaken} {Client.ResponseStatus}",
                        _serviceId, serviceCurrentDepth, xRequestId, clientId, clientId, Convert.ToInt32(activity.Duration.TotalMilliseconds), responseStatus);
                }
                else if (activity.Kind == ActivityKind.Server)
                {
                    string rootActivity = activity.Tags.FirstOrDefault(b => b.Key == ActivityConstants.ROOT_ACTIVITY).Value;
                    if (!String.IsNullOrEmpty(rootActivity))
                    {
                        contextDictionary.TryGetValue(key, out double totalChildTime);
                        var serviceUrl = (string)activity.TagObjects.FirstOrDefault(b => b.Key == "http.url").Value;
                        _logger.LogInformation("{Service.Id} {Service.Url} {Service.CurrentDepth} {x-request-id} {Service.TimeTaken} {Service.InternalTimeTaken} {Service.ResponseStatus}",
                            _serviceId, serviceUrl, serviceCurrentDepth, xRequestId, Convert.ToInt32(activity.Duration.TotalMilliseconds), Convert.ToInt32(activity.Duration.TotalMilliseconds - totalChildTime), responseStatus);
                        contextDictionary.Remove(key);
                    }
                }
            }

            return ExportResult.Success;
        }
    }
}
