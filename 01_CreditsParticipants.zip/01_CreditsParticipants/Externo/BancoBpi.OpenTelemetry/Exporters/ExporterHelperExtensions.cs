﻿using Microsoft.Extensions.Configuration;
using OpenTelemetry;
using OpenTelemetry.Trace;
using System;


namespace BancoBpi.OpenTelemetry.Extensions.Exporters
{
    public static class ExporterHelperExtensions

    {

        public static TracerProviderBuilder AddSerilogLogExporter(this TracerProviderBuilder builder, IConfiguration configuration)
        {
            if (builder == null)
            {
                throw new ArgumentNullException(nameof(builder));
            }

            return builder.AddProcessor(new SimpleActivityExportProcessor(new SerilogLogExporter(configuration)));
        }
    }
}
