﻿using BancoBpi.OpenTelemetry.Extensions.Constants;
using BancoBpi.OpenTelemetry.Extensions.Exporters;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Primitives;
using OpenTelemetry;
using OpenTelemetry.Instrumentation.AspNetCore;
using OpenTelemetry.Instrumentation.Http;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System;
using System.Diagnostics;

namespace BancoBpi.OpenTelemetry.Extensions
{
    public static class OpenTelemetryExtensions
    {
        /// <summary>
        /// Add OpemTelemetry Middleware with Jaeger and serilog exporter
        /// </summary>
        /// <param name="serviceCollection"></param>
        public static void AddOpenTelemetryWithSerilogAndJaegerExporters(this IServiceCollection serviceCollection, string applicationName, IConfiguration configuration)
        {
            var isJaegerEnables = configuration.GetValue<bool>("Jaeger:Enabled");

            //Add OpenTelemetryTracing - With this configuration the Request-Id Header is not add to the RequestId Context and consequently the header is not propagated to oyher calls.
            var resourceBuilder = ResourceBuilder.CreateDefault().AddService(applicationName);

            //Enrich HTTP activity with current requestId
            serviceCollection.Configure<HttpClientInstrumentationOptions>(options =>
            {
                options.Enrich = (activity, eventName, rawObject) =>
                {
                    if (rawObject is HttpRequest httpRequest)
                    {
                        StringValues xRequestId = getRequestId(httpRequest.Headers);
                        activity.SetTag(ActivityConstants.HEADER_X_REQUEST_ID, xRequestId);
                    }
                    if (rawObject is HttpResponse httpResponse)
                    {
                        StringValues xRequestId = getRequestId(httpResponse.Headers);
                        if (!String.IsNullOrEmpty(xRequestId))
                        {
                            activity.SetTag(ActivityConstants.HEADER_X_REQUEST_ID, xRequestId);
                        }
                    }
                };
            });

            //Enrich activity with current requestId
            serviceCollection.Configure<AspNetCoreInstrumentationOptions>(options =>
            {
                options.Enrich = (activity, eventName, rawObject) =>
                {
                    if (rawObject is HttpRequest httpRequest)
                    {
                        StringValues xRequestId = getRequestId(httpRequest.Headers);
                        if (!String.IsNullOrEmpty(xRequestId))
                        {
                            activity.SetTag(ActivityConstants.HEADER_X_REQUEST_ID, xRequestId);
                        }
                    }
                    if (rawObject is HttpResponse httpResponse)
                    {
                        StringValues xRequestId = getRequestId(httpResponse.Headers);
                        if (!String.IsNullOrEmpty(xRequestId))
                        {
                            activity.SetTag(ActivityConstants.HEADER_X_REQUEST_ID, xRequestId);
                        }
                    }
                };
            });

            if (isJaegerEnables)
            {
                serviceCollection.AddOpenTelemetryTracing((builder) => builder
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddJaegerExporter(o =>
                    {
                        o.AgentHost = !string.IsNullOrEmpty(configuration["Jaeger:AgentHost"]) ? configuration["Jaeger:AgentHost"] : "localhost";
                        o.AgentPort = Convert.ToInt32(configuration["Jaeger:AgentPort"]);


                        // Examples for the rest of the options, defaults unless otherwise specified
                        // Omitting Process Tags example as Resource API is recommended for additional tags
                        o.MaxPayloadSizeInBytes = 4096;

                        // Using Batch Exporter (which is default)
                        // The other option is ExportProcessorType.Simple
                        o.ExportProcessorType = ExportProcessorType.Simple;
                        //o.BatchExportProcessorOptions = new BatchExportProcessorOptions<Activity>()
                        //{
                        //    MaxQueueSize = 2048,
                        //    ScheduledDelayMilliseconds = 5000,
                        //    ExporterTimeoutMilliseconds = 30000,
                        //    MaxExportBatchSize = 512,
                        //};
                    })
                    .AddSerilogLogExporter(configuration)
                    .SetResourceBuilder(resourceBuilder)
                );
            }
            else
            {
                //not add Jaeger Exporter
                serviceCollection.AddOpenTelemetryTracing((builder) => builder
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .AddSerilogLogExporter(configuration)
                    .SetResourceBuilder(resourceBuilder)
                );
            }

        }

        /// <summary>
        /// Add x-request-id inside activity baggage to propagate to all child activities
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="currentDepth"></param>
        public static void ConfigureOpenTelemetry(string requestId, int currentDepth)
        {

            //baggage to propagate to all child activities
            Activity.Current?.AddBaggage(ActivityConstants.HEADER_X_REQUEST_ID, requestId);
            Activity.Current?.AddBaggage(ActivityConstants.SERVICE_CURRENT_DEPTH, currentDepth.ToString());

            //tag only afect the current activity. not propagate to childs
            Activity.Current?.AddTag(ActivityConstants.SERVICE_CURRENT_DEPTH, currentDepth);
            Activity.Current?.AddTag(ActivityConstants.ROOT_ACTIVITY, "true");

            //Add TraceState to Activity to propagate to all http child calls
            //Contains the Service.CurrentDepth and x-request-Id
            string[] traceStateArray = { ActivityConstants.SERVICE_CURRENT_DEPTH + "=" + currentDepth, ActivityConstants.HEADER_X_REQUEST_ID + "=" + requestId };
            StringValues traceStateString = new StringValues(traceStateArray);
            if (Activity.Current != null)
                Activity.Current.TraceStateString = traceStateString;
        }

        /// <summary>
        /// Add trace context to Activity 
        /// </summary>
        public static void ConfigureOpenTelemetry(IHeaderDictionary httpHeaders)
        {

            string requestId = getRequestId(httpHeaders);
            int currentDepth = getCurrentDepth(httpHeaders);

            ConfigureOpenTelemetry(requestId, currentDepth);

        }

        /// <summary>
        /// Get requestId value from Headers. If not found, set header to TraceId Value
        /// </summary>
        /// <param name="httpHeaders"></param>
        /// <returns></returns>
        public static string getRequestId(IHeaderDictionary httpHeaders)
        {
            StringValues requestId;

            if ((!httpHeaders.TryGetValue(ActivityConstants.HEADER_X_REQUEST_ID, out requestId)))
            {
                //get requestId from standard Trace Context header
                if (httpHeaders.TryGetValue(ActivityConstants.HEADER_TRACE_STATE, out StringValues correllationContext))
                {
                    foreach (var value in correllationContext)
                    {
                        foreach (string item in value.Split(","))
                        {
                            string[] itemArray = item.Split("=");
                            if (itemArray[0].ToLower().Trim().Equals(ActivityConstants.HEADER_X_REQUEST_ID.ToLower()))
                            {
                                requestId = itemArray[1];
                                break;
                            }
                        }
                        if (!String.IsNullOrEmpty(requestId))
                            break;
                    }
                }
                else
                {
                    //Header not found, get request ID from TraceId
                    requestId = Activity.Current == null ? Guid.NewGuid().ToString() : Activity.Current.TraceId.ToString();
                }
                //add value to header to be propagated to the other services
                httpHeaders.Add(ActivityConstants.HEADER_X_REQUEST_ID, requestId);
            }
            return requestId;
        }

        /// <summary>
        /// Get CurrentDepth value from headers
        /// </summary>
        /// <param name="httpHeaders"></param>
        /// <returns></returns>
        private static int getCurrentDepth(IHeaderDictionary httpHeaders)
        {
            int currentDepth = 0;

            //get currentDepth from standard Trace Context header
            if (httpHeaders.TryGetValue(ActivityConstants.HEADER_TRACE_STATE, out StringValues correllationContext))
            {
                foreach (var value in correllationContext)
                {
                    foreach (string item in value.Split(","))
                    {
                        string[] itemArray = item.Split("=");
                        if (itemArray[0].ToLower().Trim().Equals(ActivityConstants.SERVICE_CURRENT_DEPTH.ToLower()))
                        {
                            currentDepth = int.Parse(itemArray[1]) + 1;
                            break;
                        }
                    }
                    if (currentDepth > 0)
                        break;
                }
            }
            else
            {
                currentDepth = 1;
            }

            return currentDepth;
        }
    }
}
