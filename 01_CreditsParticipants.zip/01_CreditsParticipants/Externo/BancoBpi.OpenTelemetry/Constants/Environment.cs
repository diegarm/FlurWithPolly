﻿namespace BancoBpi.OpenTelemetry.Extensions.Constants
{
    public enum Environment
    {
        Local = 0,
        Test = 1,
        Development = 2,
        Staging = 3,
        PreProduction = 4,
        Production = 5
    }
}
