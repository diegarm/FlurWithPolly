﻿namespace BancoBpi.OpenTelemetry.Extensions.Constants
{

    public static class ActivityConstants
    {
        /// <summary>
        /// Header key to provide additional vendor-specific trace identification information across different distributed tracing systems
        /// </summary>
        public const string HEADER_TRACE_STATE = "tracestate";

        /// <summary>
        /// Key for Activity x-request-id
        /// </summary>
        public const string HEADER_X_REQUEST_ID = "x-request-id";

        /// <summary>
        /// Key for Activity service.currentDepth
        /// </summary>
        public const string SERVICE_CURRENT_DEPTH = "service.currentdepth";

        /// <summary>
        /// key to indicate if is the parent activity
        /// </summary>
        public const string ROOT_ACTIVITY = "root-activity";
    }
}
