﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using OpenTelemetry.Resources;
using BancoBpi.Pluggable.API.Context;
using BancoBpi.Pluggable.API.Interceptors;
using OpenTelemetry;
using OpenTelemetry.Trace;
using System;
using BancoBpi.Pluggable.API.Cache;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using BancoBpi.Pluggable.API.Domain;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using BancoBpi.OpenTelemetry.Extensions;

namespace BancoBpi.Pluggable.API.Hateoas.Extension
{
    public static class ServiceCollectionExtensions
    {

        private static readonly string ENVIRONMENT_LOCAL = "Local";
        public static IServiceCollection AddPluggableCore(this IServiceCollection services, IWebHostEnvironment webHostEnvironment, Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            services
                .AddScoped<IPluggableExecutionContext, PluggableExecutionContext>()
                .AddScoped<IContextInfo, ContextInfo>()
                .AddSingleton<ICacheProvider, CacheProvider>()
                .AddSingleton<HttpClient>(new HttpClient())
                .AddPluggableErrorModelHandling()
                .AddPluggableHateoas();

            if(!webHostEnvironment.IsEnvironment(ENVIRONMENT_LOCAL))
                services.AddOpenTelemetryWithSerilogAndJaegerExporters(webHostEnvironment.ApplicationName, configuration);

            services.AddHealthChecks();

            return services;
        }

        private static IServiceCollection AddPluggableHateoas(this IServiceCollection services)
        {
            return services
                .AddScoped<IKindGenerator, KindGenerator>()
                .AddScoped<IHateoasGenerator, HateoasGenerator>();
        }

        private static void AddOpenTelemetry(this IServiceCollection serviceCollection, IWebHostEnvironment webHostEnvironment, Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            //Add OpenTelemetryTracing - With this configuration the Request-Id Header is not add to the RequestId Context and consequently the header is not propagated to oyher calls.
            var resourceBuilder = ResourceBuilder.CreateDefault().AddService(webHostEnvironment.ApplicationName);
            serviceCollection.AddOpenTelemetryTracing((builder) => builder
                .AddAspNetCoreInstrumentation()
                .AddHttpClientInstrumentation()
                .AddJaegerExporter(o =>
                {
                    o.AgentHost = !string.IsNullOrEmpty(configuration["Jaeger:AgentHost"]) ? configuration["Jaeger:AgentHost"] : "localhost";
                    o.AgentPort = Convert.ToInt32(configuration["Jaeger:AgentPort"]);
                    

                    // Examples for the rest of the options, defaults unless otherwise specified
                    // Omitting Process Tags example as Resource API is recommended for additional tags
                    o.MaxPayloadSizeInBytes = 4096;

                    // Using Batch Exporter (which is default)
                    // The other option is ExportProcessorType.Simple
                    o.ExportProcessorType = ExportProcessorType.Simple;
                    //o.BatchExportProcessorOptions = new BatchExportProcessorOptions<Activity>()
                    //{
                    //    MaxQueueSize = 2048,
                    //    ScheduledDelayMilliseconds = 5000,
                    //    ExporterTimeoutMilliseconds = 30000,
                    //    MaxExportBatchSize = 512,
                    //};
                })
                //.AddConsoleExporter(options => options.Targets = ConsoleExporterOutputTargets.Debug)
                //.AddSource(MonitoringInterceptor.Source)
                //TODO: Vale a pena termos o MonitorInterceptor?!?! Não está repetido sobre o pipeline?
                .SetResourceBuilder(resourceBuilder)
            );
        }

        private static IServiceCollection AddPluggableErrorModelHandling(this IServiceCollection services)
        {            
            // adding traceId value on model validation
            services.Configure((Action<ApiBehaviorOptions>)(options =>
            {
                ErrorModelExtraData(services, options);
            }));

            return services;
        }

        [MonitoringInterceptor]
        private static void ErrorModelExtraData(IServiceCollection services, ApiBehaviorOptions options)
        {
            options.InvalidModelStateResponseFactory = context =>
            {
                var problemDetails = new ValidationProblemDetails(context.ModelState);
                var executionContext = services.BuildServiceProvider().GetService<IPluggableExecutionContext>();

                executionContext.SetRequestId(context.HttpContext);

                problemDetails.Extensions[IContextConstants.ErrorRequestIdValue] = executionContext.GetRequestId();

                return new BadRequestObjectResultLog(context, problemDetails)
                {
                    ContentTypes = { "application/problem+json", "application/problem+xml" },
                };
            };
        }
    }
}
