﻿using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;

namespace BancoBpi.Pluggable.API.Extensions
{
    /// <summary>
    /// Class mapper extension, used to automatically inject profiles - It isn't necessary to change these settings.
    /// </summary>
    public static class MapperExtension
    {
        private static string ASSEMBLY_BASE = "bpi";
        private static Assembly _assembly;

        private static IEnumerable<Assembly> GetListOfEntryAssembly()
        {
            var listOfAssemblies = new List<Assembly>();
            listOfAssemblies.Add(_assembly);

            foreach (var refAsmName in _assembly.GetReferencedAssemblies().Where(a => a.FullName.ToLower().Contains(ASSEMBLY_BASE)))
            {
                listOfAssemblies.Add(Assembly.Load(refAsmName));
                Debug.WriteLine($"Plugg automapper - Finding in assembly: {refAsmName}");
            }

            return listOfAssemblies;
        }

        private static IEnumerable<Assembly> GetListAssemblyWithProfile()
        {
            var assemblies = GetListOfEntryAssembly();
            var listAssembly = new List<Assembly>();

            foreach (var item in assemblies)
            {
                var iProfile = typeof(Profile);
                var types = item.GetTypes()
                                    .Where(c =>
                                    c.IsClass == true &&
                                    c.BaseType == iProfile)
                                    .ToList();

                if (types.Count > 0)
                {
                    listAssembly.Add(item);
                    Debug.WriteLine($"Plugg automapper - Add assembly: {item.FullName}");
                }
            }

            return listAssembly;
        }

        public static IServiceCollection AddAutoMapperConfiguration(this IServiceCollection services, Assembly assembly)
        {
            _assembly = assembly;
            var typesMapperInjection = GetListAssemblyWithProfile();
            services.AddAutoMapper(typesMapperInjection);
            return services;
        }

    }
}
