﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Extensions
{
    public static class ILoggerExtension
    {
        public static void LogClientTime(this ILogger log, string ClientId, string responseStatus, long timeTaken)
        {
            log.LogInformation("{Client.TimeTaken} {Client.ResponseStatus} {Client.ServiceId}", timeTaken, responseStatus, ClientId);
        }
    }
}
