﻿using Microsoft.AspNetCore.Builder;
using BancoBpi.Pluggable.API.Middlewares;

namespace BancoBpi.Pluggable.API.Extensions
{
    public static class ApplicationBuilderExtensions
    {
        public static void UsePluggableCore(this IApplicationBuilder app)
        {
            // Middleware para monitorizar tempos de execução do serviço
            app.UseMiddleware<MonitoringMiddleware>();
            // Middleware para tratamento de erros
            app.UseMiddleware<ErrorHandlerMiddleware>();
            // Middleware para definir contexto  de execução
            app.UseMiddleware<ExecutionContextMiddleware>();            

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health");
            });
        }

        
    }
}
