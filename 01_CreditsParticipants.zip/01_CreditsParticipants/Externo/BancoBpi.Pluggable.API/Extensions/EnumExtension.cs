﻿using System;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace BancoBpi.Pluggable.API.Extensions
{
    public static class EnumExtension
    {
        public static string AttrValue<T>(this T value)
        where T : Enum
        {
            var declaredMembers = typeof(T).GetTypeInfo().DeclaredMembers;
            string converted = value.ToString();
            long result;
            if (long.TryParse(converted, out result))
            {
                var el = declaredMembers.ToArray()[result + 1];
                var attr = el.GetCustomAttribute<EnumMemberAttribute>();
                converted =  attr.Value;
            }
            else
            {
                converted = declaredMembers
                    .SingleOrDefault(x => x.Name == value.ToString())
                    ?.GetCustomAttribute<EnumMemberAttribute>(false)
                    ?.Value;
            }

            return converted;
        }

    }
}
