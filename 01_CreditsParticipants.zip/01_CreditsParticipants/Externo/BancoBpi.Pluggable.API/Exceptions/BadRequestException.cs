﻿using System.Net;
using Microsoft.Extensions.Logging;

namespace BancoBpi.Pluggable.API.Exceptions
{
    public class BadRequestException : PluggableException
    {
        private const string defaultTitle = "Bad Request";
        private const string type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.1";

        public BadRequestException() : this("", defaultTitle)
        { }

        public BadRequestException(System.Exception exception) : this(exception.Message)
        { }

        public BadRequestException(string message, string title = defaultTitle) : base(message, title, (int)HttpStatusCode.BadRequest)
        {
            Type = type;
            LogLevel = LogLevel.Information;
        }
    }
}
