﻿using Microsoft.Extensions.Logging;
using System.Net;

namespace BancoBpi.Pluggable.API.Exceptions
{
    public class PluggableException : System.Exception
    {
        public string Title { get; set; }

        public int StatusCode { get; set; }

        public string TraceId { get; set; }

        public string Type { get; set; }

        public string Instance { get; set; }

        public LogLevel LogLevel { get; internal set; }
        
        private const string defaultTitle = "Internal error";

        public PluggableException() : this(string.Empty, defaultTitle)
        { }

        public PluggableException(System.Exception exception, string title = defaultTitle, int httpStatusCode = (int)HttpStatusCode.InternalServerError) : this(exception.Message, title, httpStatusCode)
        {
        }

        public PluggableException(string message, string title = defaultTitle, int httpStatusCode = (int)HttpStatusCode.InternalServerError) : base(message)
        {
            StatusCode = httpStatusCode;
            Title = title;
            LogLevel = LogLevel.Error;
        }
    }
}
