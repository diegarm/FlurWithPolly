﻿using System.Net;
using Microsoft.Extensions.Logging;

namespace BancoBpi.Pluggable.API.Exceptions
{
    public class NotFoundException : PluggableException
    {
        private const string defaultTitle = "Not found";
        private const string type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.4";

        public NotFoundException() : this("", defaultTitle)
        { }

        public NotFoundException(System.Exception exception) : this(exception.Message)
        { }
        
        public NotFoundException(string message, string title = defaultTitle) : base(message, title, (int) HttpStatusCode.NotFound)
        {
            Type = type;
            LogLevel = LogLevel.Information;
        }         
    }
}
