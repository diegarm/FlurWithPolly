﻿using BancoBpi.Pluggable.API.Exceptions;
using System;
using System.Collections.Generic;
using System.Text.Json;

namespace BancoBpi.Pluggable.API.Domain
{
    public class RequestInfo
    {
        /// <summary>
        /// The timestamp when the proxy receives the first byte of the request.
        /// </summary>
        /// <value>The timestamp when the proxy receives the first byte of the request.</value>        
        public string Time { get; set; }

        /// <summary>
        /// The unique ID for a request, which can be propagated to downstream systems. The ID should have low probability of collision within a single day for a specific service. For HTTP requests, it should be X-Request-ID or equivalent.
        /// </summary>
        /// <value>The unique ID for a request, which can be propagated to downstream systems. The ID should have low probability of collision within a single day for a specific service. For HTTP requests, it should be X-Request-ID or equivalent.</value>
        public string Id { get; set; }


        /// <summary>
        /// The HTTP request method, such as GET, POST.
        /// </summary>
        /// <value>The HTTP request method, such as GET, POST.</value>
        //[TypeConverter(typeof(CustomEnumConverter<MethodEnum>))]
        //[JsonConverter(typeof(Newtonsoft.Json.Converters.StringEnumConverter))]   
        public enum MethodEnum
        {
            GET,
            POST,
            DELETE,
            PUT,
            PATCH
        }

        /// <summary>
        /// The HTTP request method, such as GET, POST.
        /// </summary>
        /// <value>The HTTP request method, such as GET, POST.</value>
        public virtual MethodEnum Method { get; set; }

        /// <summary>
        /// Gets or Sets request headers
        /// </summary>
        public Dictionary<string, string> Headers { get; set; } = new Dictionary<string, string>();

        /// <summary>
        /// The request target, as it appears in the first line of the HTTP request. This includes the URL path and query-string. No decoding is performed.
        /// </summary>
        /// <value>The request target, as it appears in the first line of the HTTP request. This includes the URL path and query-string. No decoding is performed.</value>
        public string Path { get; set; }

        /// <summary>
        ///   Gets or sets the base path for the request. The path base should not end with
        /// </summary>
        /// <value>The base path for the request</value>
        public string PathBase { get; set; }

        /// <summary>
        ///  The HTTP request Host .
        /// </summary>
        /// <value> The HTTP request Host .</value>
        public HostInfo Host = new();


        /// <summary>
        /// The HTTP URL scheme, such as http and https.
        /// </summary>
        /// <value>The HTTP URL scheme, such as http and https.</value>
        public enum SchemeEnum
        {
            http,
            https
        }

        /// <summary>
        /// The HTTP URL scheme, such as http and https.
        /// </summary>
        /// <value>The HTTP URL scheme, such as http and https.</value>
        public SchemeEnum Scheme { get; set; }

        /// <summary>
        /// The HTTP request size in bytes. If unknown, it must be -1.
        /// </summary>
        /// <value>The HTTP request size in bytes. If unknown, it must be -1.</value>
        public long? ContentLength { get; set; }

        /// <summary>
        /// The HTTP request content type.
        /// </summary>
        /// <value>The HTTP request size content type</value>
        public string ContentType { get; set; }

        /// <summary>
        /// The HTTP request body.
        /// </summary>
        /// <value>The HTTP request body.</value>
        public string Body { get; set; }

        public ForwardInfo ForwardInfo => Headers == null ? new() : GetForwardInfoFromHeader(Headers);

        private ForwardInfo GetForwardInfoFromHeader(Dictionary<string, string> headers)
        {
            if (headers is null)
            {
                throw new PluggableException(nameof(headers));
            }

            try
            {
                Headers.TryGetValue(IContextConstants.XForwardedFor, out string forValue);
             
                if (!Headers.ContainsKey(IContextConstants.XForwardedProto) ||
                    !Headers.ContainsKey(IContextConstants.XForwardedPrefix) ||
                    !Headers.ContainsKey(IContextConstants.XForwardedHost))
                {
                    return new ForwardInfo()
                    {
                        Proto = Scheme.ToString(),
                        Prefix = $"{PathBase.Trim()}/",
                        Host = $"{Host.Host.Trim()}:{Host.Port}",
                        For = forValue
                    };
                }

                return new ForwardInfo()
                {
                    Proto = Headers[IContextConstants.XForwardedProto],
                    Prefix = Headers[IContextConstants.XForwardedPrefix],
                    Host = Headers[IContextConstants.XForwardedHost],
                    For = forValue
                };

            } catch(Exception e)
            {
                throw new PluggableException($"{e.Message}: " +
                    $"{IContextConstants.XForwardedProto}, {IContextConstants.XForwardedPrefix} and {IContextConstants.XForwardedHost}");
            }            
        }

        public ApiRuntimeInfo ApiRuntimeInfo => Headers == null ? new() : GetApiRuntimeInfoFromHeader(Headers);

        private ApiRuntimeInfo GetApiRuntimeInfoFromHeader(Dictionary<string, string> headers)
        {
            if (headers is null)
            {
                throw new PluggableException(nameof(headers));
            }

            try
            {
                var apiName = Headers.GetValueOrDefault(IContextConstants.XApiName, "DefaultApiName");
                var apiVersion = Headers.GetValueOrDefault(IContextConstants.XMajorVersion, "v1");

                return new ApiRuntimeInfo()
                {
                    Name = apiName,
                    MajorVersion = apiVersion
                };
            }
            catch
            {
                throw new PluggableException($"Must be informed all Headers: " +
                    $"{IContextConstants.XApiName} and {IContextConstants.XMajorVersion}");
            }
        }

        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public virtual string ToJson()
        {
            return JsonSerializer.Serialize(this);
        }

    }
}
