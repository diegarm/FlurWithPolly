﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class CommonBodyLinks
    {
        public Links Self { get; set; }
    }
}
