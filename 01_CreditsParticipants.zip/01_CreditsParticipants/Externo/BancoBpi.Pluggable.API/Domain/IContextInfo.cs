﻿using System.Collections.Generic;

namespace BancoBpi.Pluggable.API.Domain
{
    public interface IContextInfo
    {
        string ClientID { get; set; }
        string ClientIpAdress { get; set; }
        IDictionary<string, string> Properties { get; set; }

        string ToJson();
    }
}