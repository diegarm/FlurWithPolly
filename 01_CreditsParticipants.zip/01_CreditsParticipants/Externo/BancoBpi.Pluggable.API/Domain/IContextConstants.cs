﻿namespace BancoBpi.Pluggable.API.Domain
{
    public interface IContextConstants
    {
        /// <summary>
        /// Context HTTP Header name.
        /// ORIGIN: API GW
        /// </summary>
        public const string XApiContext = "x-api-context";

        public const string XClientId = "x-client-id";

        public const string XRequestId = "x-request-id";

        public const string XForwardedProto = "x-forwarded-proto";

        public const string XForwardedPrefix = "x-forwarded-prefix";

        public const string XForwardedHost = "x-forwarded-host";

        public const string XForwardedFor = "x-forwarded-for";

        public const string XApiName = "x-api-name";

        public const string XMajorVersion = "x-api-major-version";

        public const string ErrorRequestIdValue = "request-id";
    }
}
