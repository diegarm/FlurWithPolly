﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class Paginated
    {
        public Paginated()
        {
        }

        public Paginated(Paginated paginated)
        {
            TotalItems = paginated.TotalItems;
            CurrentPage = paginated.CurrentPage;
            TotalPages = paginated.TotalPages;
            Links = paginated.Links;
        }

        public int TotalItems { get; set; }

        public int CurrentPage { get; set; }

        public int TotalPages { get; set; }

        public PaginationBodyLinks Links { get; set; }

        public bool HasPagination()
        {
            return TotalPages > 0;
        }
    }
}
