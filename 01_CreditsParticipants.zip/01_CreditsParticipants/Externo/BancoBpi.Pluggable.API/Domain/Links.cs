﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class Links
    {
        public string Href { get; set; }
    }
}
