﻿using System.Text.Json;

namespace BancoBpi.Pluggable.API.Domain
{
    public class ApiRuntimeInfo
    {
        /// <summary>
        /// REQUIRED. The Api name
        /// </summary>        
        public string Name { get; set; }

        /// <summary>
        /// REQUIRED. The API URI
        /// </summary>        
        public string Uri { get; set; }

        /// <summary>
        /// REQUIRED. The Api major version
        /// </summary>        
        public string MajorVersion { get; set; }        

        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
