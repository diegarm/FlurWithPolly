﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class HostInfo
    {
        //
        // Summary:
        //     Returns the value of the host part of the value. The port is removed if it was
        //     present. IPv6 addresses will have brackets added if they are missing.
        //
        // Returns:
        //     The host portion of the value.
        public string Host { get; set; }

        //
        // Summary:
        //     Returns the value of the port part of the host, or null if none is found.
        //
        // Returns:
        //     The port portion of the value.
        public int? Port { get; set; }
    }
}