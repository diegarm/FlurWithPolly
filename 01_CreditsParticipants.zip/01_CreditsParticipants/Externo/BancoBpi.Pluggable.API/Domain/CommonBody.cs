﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class CommonBody
    {
        public string Id { get; set; }

        public string Kind { get; set; }

        public CommonBodyLinks Links { get; set; }
    }
}
