﻿using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.Text.Json;

namespace BancoBpi.Pluggable.API.Domain
{
    public class ContextInfo : IContextInfo
    {
        /// <summary>
        /// Context properties        
        /// </summary>
        public virtual IDictionary<string, string> Properties { get; set; } = new Dictionary<string, string>();

        /// <summary>The ip address of the request initializer</summary>
        public virtual string ClientIpAdress { get; set; }

        /// <summary>
        /// The Client ID received in the header
        /// </summary>
        public virtual string ClientID { get; set; }

        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public virtual string ToJson()
        {
            return JsonSerializer.Serialize(this);
        }

    }
}
