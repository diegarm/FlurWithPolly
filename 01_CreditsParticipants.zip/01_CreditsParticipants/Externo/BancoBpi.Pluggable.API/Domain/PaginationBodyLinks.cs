﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class PaginationBodyLinks
    {
        public Links Self { get; set; }

        public Links Next { get; set; }

        public Links Prev { get; set; }
    }
}
