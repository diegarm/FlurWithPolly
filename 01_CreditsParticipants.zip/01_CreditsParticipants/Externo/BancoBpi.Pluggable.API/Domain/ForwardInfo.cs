﻿using BancoBpi.Pluggable.API.Exceptions;
using BancoBpi.Pluggable.API.Extensions;

namespace BancoBpi.Pluggable.API.Domain
{
    public class ForwardInfo
    {
        public string Proto { get; set; }

        private string _prefix;

        public string Prefix { 
            get => _prefix;
            set
            {                
                Resource = GetResourceValue(value);
                _prefix = GetPrefixValueWithoutResource(value);
                if (!_prefix.EndsWith("/"))
                {
                    _prefix += "/";
                }
                if (!_prefix.StartsWith("/"))
                {
                    _prefix = "/" + _prefix;
                }
            }
        }
        public string Resource { get; private set; }
        public string Host { get; set; }
        public string For { get; set; }

        public string FullURL => $"{Proto}://{Host}{Prefix}";

        private string GetResourceValue(string prefix)
        {
            int lastIndex = prefix.LastIndexOf('/') + 1;

            if (lastIndex == 0) throw new PluggableException($"Header: {IContextConstants.XForwardedPrefix} invalid. Must be a valid URL.");

            string resource = prefix[lastIndex..];

            if (!resource.IsGuidOrNumber()) return resource;

            return GetResourceValue(prefix.Substring(0, lastIndex - 1));
        }
        private string GetPrefixValueWithoutResource(string prefix)
        {
            int index = prefix.LastIndexOf('/');

            if (index == 0) throw new PluggableException($"Header: {IContextConstants.XForwardedPrefix} invalid. Must be a valid URL.");

            return prefix.Substring(0, index);
        }
    }
}
