﻿namespace BancoBpi.Pluggable.API.Domain
{
    public class Page
    {
        private const int DEFAULT_PAGE_SIZE = 10;
        private const int DEFAULT_PAGE_NUMBER = 1;

        private readonly int? _pageNumber;
        private readonly int? _pageSize;
        private readonly bool _isDefault;

        private Page(int? pageNumber, int? pageSize, bool isDefault = false)
        {
            _pageNumber = pageNumber;
            _pageSize = pageSize;
            _isDefault = isDefault | (pageSize == null && pageNumber == null);
        }

        public static Page Of(int? pageNumber, int? pageSize)
        {
            return new Page(pageNumber, pageSize);
        }

        public static Page Of(int? pageNumber)
        {
            return new Page(pageNumber, null);
        }

        public static Page Empty()
        {
            return new Page(null, null, true);
        }

        public bool IsEmpty()
        {
            return _isDefault;
        }

        public int PageNumber()
        {
            return _pageNumber < 1 ? DEFAULT_PAGE_NUMBER : _pageNumber ?? DEFAULT_PAGE_NUMBER;
        }

        public int PageSize()
        {
            return _pageSize < 1 ? DEFAULT_PAGE_SIZE : _pageSize ?? DEFAULT_PAGE_SIZE;
        }
    }
}
