﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;
using BancoBpi.Pluggable.API.Context;
using BancoBpi.Pluggable.API.Domain;
using BancoBpi.Pluggable.API.Interceptors;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Middlewares
{
    //TODO copiar esse codigo para o outro projeto e testar
    public class ExecutionContextMiddleware : IPluggableMiddleware
    {
        private readonly ILogger _logger;
        private readonly RequestDelegate _nextMiddleware;

        public ExecutionContextMiddleware(RequestDelegate nextMiddleware, ILogger<ExecutionContextMiddleware> logger)
        {
            this._logger = logger;
            this._nextMiddleware = nextMiddleware;
        }

        public async Task InvokeAsync(HttpContext context, IPluggableExecutionContext executionContext)
        {
            await executionContext.SetRequestInfoAsync(context);
            executionContext.SetContextInfo(context);
            await _nextMiddleware(context);
        }

        private static IDictionary<string, object> CreateLoggerScopePropertiesFromContext(IPluggableExecutionContext executionContext)
        {            
            var apiName = executionContext.GetRequestInfo().ApiRuntimeInfo.Name;
            var apiMajorVersion = executionContext.GetRequestInfo().ApiRuntimeInfo.MajorVersion;           

            return new Dictionary<string, object>
            {
                [IContextConstants.XApiContext] = apiName,
                [IContextConstants.XApiName] = apiName,
                [IContextConstants.XMajorVersion] = apiMajorVersion
            };
        }
    }
}
