﻿using Microsoft.AspNetCore.Http;
using BancoBpi.Pluggable.API.Context;
using BancoBpi.Pluggable.API.Interceptors;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Middlewares
{
    public interface IPluggableMiddleware
    {
        [MonitoringInterceptor]
        Task InvokeAsync(HttpContext context, IPluggableExecutionContext executionContext);
    }
}
