﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;
using BancoBpi.Pluggable.API.Context;
using BancoBpi.Pluggable.API.Domain;
using BancoBpi.Pluggable.API.Interceptors;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Middlewares
{
    public class MonitoringMiddleware : IPluggableMiddleware
    {
        private readonly ILogger _logger;
        private readonly RequestDelegate _nextMiddleware;

        public MonitoringMiddleware(RequestDelegate nextMiddleware, ILogger<MonitoringMiddleware> logger)
        {
            this._logger = logger;
            this._nextMiddleware = nextMiddleware;
        }

        public async Task InvokeAsync(HttpContext context, IPluggableExecutionContext executionContext)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            //Add RequestId to the execution Context
            executionContext.SetRequestId(context);

            using (_logger.BeginScope(CreateLoggerScopePropertiesFromContext(executionContext)))
            {
                try
                {
                    await _nextMiddleware(context);
                }
                finally
                {
                    stopWatch.Stop();
                    // Get the elapsed time as a TimeSpan value.
                    long totalTime = stopWatch.ElapsedMilliseconds;
                    _logger.LogInformation("Pluggable: {Service.TimeTaken} {Service.ResponseStatus}", totalTime, context.Response.StatusCode);
                }
            }
        }
        private static IDictionary<string, object> CreateLoggerScopePropertiesFromContext(IPluggableExecutionContext executionContext)
        {
            var apiName = executionContext.GetRequestInfo().ApiRuntimeInfo.Name;
            var apiMajorVersion = executionContext.GetRequestInfo().ApiRuntimeInfo.MajorVersion;

            return new Dictionary<string, object>
            {
                [IContextConstants.XRequestId] = executionContext.GetRequestId(),
                [IContextConstants.XApiContext] = apiName,
                [IContextConstants.XApiName] = apiName,
                [IContextConstants.XMajorVersion] = apiMajorVersion
            };
        }
    }
}
