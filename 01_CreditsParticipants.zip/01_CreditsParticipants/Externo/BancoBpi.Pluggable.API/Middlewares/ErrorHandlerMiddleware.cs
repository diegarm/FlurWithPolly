﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using BancoBpi.Pluggable.API.Context;
using BancoBpi.Pluggable.API.Domain;
using BancoBpi.Pluggable.API.Exceptions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Middlewares
{
    public class ErrorHandlerMiddleware : IPluggableMiddleware
    {
        private readonly ILogger _logger;
        private readonly RequestDelegate nextMiddleware;

        public ErrorHandlerMiddleware(RequestDelegate nextMiddleware, ILogger<ErrorHandlerMiddleware> logger)
        {
            this._logger = logger;
            this.nextMiddleware = nextMiddleware;
        }

        public async Task InvokeAsync(HttpContext context, IPluggableExecutionContext executionContext)
        {
            {
                _logger.LogDebug("Pluggable: Base scope's values defined");

                try
                {
                    context.Response.Headers.Add("X-Request-Id", executionContext.GetRequestId());
                    await nextMiddleware(context);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Exception: {ex.ToString()}");
                    var response = context.Response;
                    response.ContentType = "application/problem+json";

                    Exception exception = ex.InnerException ?? ex;

                    string errorType;
                    string errorTitle;
                    string errorDetail;
                    LogLevel logLevel;

                    switch (exception)
                    {
                        case PluggableException pluggableException:
                            response.StatusCode = pluggableException.StatusCode;
                            errorType = pluggableException.Type;
                            errorTitle = pluggableException.Title;
                            errorDetail = pluggableException.Message;
                            logLevel = pluggableException.LogLevel;
                            break;
                        default:
                            logLevel = LogLevel.Error;
                            response.StatusCode = (int)HttpStatusCode.InternalServerError;
                            errorType = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.6.1"; //TODO To review this point
                            errorTitle = "internal_server_error";
                            errorDetail = "One internal error occurred.";   // TODO: Não queremos enviar o detalhe da excepção?
                            break;
                    }

                    _logger.Log(logLevel, ex, ex.Message);

                    var problemDetails = new ProblemDetails
                    {
                        Status = response.StatusCode,
                        Type = errorType,
                        Title = errorTitle,
                        Detail = errorDetail
                    };

                    problemDetails.Extensions[IContextConstants.ErrorRequestIdValue] = executionContext.GetRequestId();

                    string result = JsonSerializer.Serialize(problemDetails);

                    //Replace the body content
                    await response.WriteAsync(result);
                }
            }
        }
    }
}
