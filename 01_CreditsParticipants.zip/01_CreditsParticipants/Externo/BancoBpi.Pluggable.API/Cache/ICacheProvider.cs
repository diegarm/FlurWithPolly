﻿namespace BancoBpi.Pluggable.API.Cache
{
    public interface ICacheProvider
    {
        T GetCacheEntry<T>(string key) where T : class;
        void SetCacheEntry<T>(string key, T value) where T : class;
        void RemoveCacheEntry(string key);
    }
}
