﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;

namespace BancoBpi.Pluggable.API.Cache
{
    public class CacheProvider : ICacheProvider
    {
        private readonly IMemoryCache _cache;
        private readonly IConfiguration _configuration;

        private readonly int _expirationTime;

        public CacheProvider(IConfiguration configuration)
        {
            _configuration = configuration;
            _expirationTime = GetExpirationTime();

            _cache = new MemoryCache(new MemoryCacheOptions
            {
                SizeLimit = GetCacheSize()
            });
        }

        /// <summary>
        /// Gets the cache size (number of entries). Default value: 100 entries
        /// </summary>
        /// <returns>Cache size</returns>
        private int GetCacheSize()
        {
            string key = "CacheProvider:CacheSize";
            return int.TryParse(_configuration[key], out int size) ? size : 100;
        }

        public T GetCacheEntry<T>(string key) where T : class
        {
            var entry = _cache.Get(key);
            return entry as T;
        }

        public void RemoveCacheEntry(string key)
        {
            _cache.Remove(key);
        }

        public void SetCacheEntry<T>(string key, T value) where T : class
        {
            var cacheEntryOptions = new MemoryCacheEntryOptions()
            // Set cache entry size.
            .SetSize(1)
            // Keep in cache for this time, set the relative expiration time to one hour.
            .SetAbsoluteExpiration(TimeSpan.FromHours(_expirationTime));
            _cache.Set(key, value, cacheEntryOptions);
        }

        /// <summary>
        /// Gets the cache expiration time in Hours. Default value: 1 hour
        /// </summary>
        /// <returns>Expiration time in hours</returns>
        private int GetExpirationTime()
        {
            string key = "CacheProvider:ExpirationTime";
            return int.TryParse(_configuration[key], out int expirationTime) ? expirationTime : 1;
        }
    }
}
