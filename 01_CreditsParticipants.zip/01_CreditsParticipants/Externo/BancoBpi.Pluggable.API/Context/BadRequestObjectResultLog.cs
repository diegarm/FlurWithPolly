﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Context
{
    public class BadRequestObjectResultLog : BadRequestObjectResult
    {
        public BadRequestObjectResultLog(ActionContext context, ValidationProblemDetails problemDetails) :
            base (problemDetails)
        {
            GetLog(context).LogError("Pluggable: Error validating model {Errors}", problemDetails.Errors);
        }
        private ILogger GetLog(ActionContext context)
        {
            return context.HttpContext.RequestServices.
                                GetRequiredService<ILogger<BadRequestObjectResultLog>> ();
        }
    }
}
