﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using BancoBpi.Pluggable.API.Domain;
using BancoBpi.Pluggable.API.Exceptions;
using BancoBpi.Pluggable.API.Extensions;
using BancoBpi.Pluggable.API.Interceptors;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Context
{
    public class PluggableExecutionContext : IPluggableExecutionContext
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;

        private readonly RequestInfo _requestInfo = new();
        private readonly IContextInfo _contextInfo;

        public PluggableExecutionContext(IContextInfo contextInfo, ILogger<PluggableExecutionContext> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _contextInfo = contextInfo;
        }

        public string GetRequestId()
        {
            return _requestInfo.Id;
        }

        public IContextInfo GetContextInfo()
        {
            return _contextInfo;
        }

        public RequestInfo GetRequestInfo()
        {
            return _requestInfo;
        }

        public void SetRequestId(HttpContext context)
        {
            if (!context.Request.Headers.TryGetValue(IContextConstants.XRequestId, out StringValues requestIdValue))
            {
                requestIdValue = Guid.NewGuid().ToString();
            }
            _requestInfo.Id = requestIdValue;
        }

        public void SetContextInfo(HttpContext context)
        {
            try
            {
                // Add client's ip address into omnichannel context
                var remoteIpAddress = context.Connection?.RemoteIpAddress?.MapToIPv4().ToString();
                _logger.LogDebug($"Pluggable: Remote Ip Address from the request initializer. remoteIpAddress: {remoteIpAddress}");
                _contextInfo.ClientIpAdress = remoteIpAddress;

                context.Request.Headers.TryGetValue(IContextConstants.XApiContext, out StringValues xApiContextHeader);
                if (xApiContextHeader.Count == 1)
                {
                    _contextInfo.Properties = JsonSerializer.Deserialize<Dictionary<string, string>>(xApiContextHeader);
                }

                _contextInfo.ClientID = GetRequestInfo().Headers.GetValueOrDefault(IContextConstants.XClientId, "");
                _contextInfo.Properties.Add(IContextConstants.XRequestId, xApiContextHeader);
                _contextInfo.Properties.Add(IContextConstants.XApiContext, GetRequestInfo().ApiRuntimeInfo.Name);
                _contextInfo.Properties.Add(IContextConstants.XApiName, GetRequestInfo().ApiRuntimeInfo.Name);
                _contextInfo.Properties.Add(IContextConstants.XMajorVersion, GetRequestInfo().ApiRuntimeInfo.MajorVersion);

                _logger.LogDebug("Pluggable: {ContextInfo}", _contextInfo);
            } catch(Exception ex)
            {
                _logger.LogError(ex, "Pluggable: SetContextInfo error {ContextInfo}", _contextInfo);
                throw new PluggableException(ex);
            }            
        }          

        public async Task SetRequestInfoAsync(HttpContext context)
        {
            _requestInfo.Time = DateTime.UtcNow.ToString();
            _requestInfo.Method = (RequestInfo.MethodEnum)Enum.Parse(typeof(RequestInfo.MethodEnum), context.Request.Method.ToString(), true);
            foreach (KeyValuePair<string, StringValues> header in context.Request.Headers)
            {
                _requestInfo.Headers.Add(header.Key.ToLower(), header.Value);
            }
            _requestInfo.Path = context.Request.Path;
            _requestInfo.PathBase = context.Request.PathBase;
            _requestInfo.Host.Host = context.Request.Host.Host;
            _requestInfo.Host.Port = context.Request.Host.Port;
            _requestInfo.Scheme = (RequestInfo.SchemeEnum)Enum.Parse(typeof(RequestInfo.SchemeEnum), context.Request.Scheme, true);
            _requestInfo.ContentType = context.Request.ContentType;
            _requestInfo.ContentLength = context.Request.ContentLength != null ? context.Request.ContentLength : null;
            _requestInfo.Body = context.Request.ContentLength != null ? await context.Request.GetRawBodyAsync() : null;

            _logger.LogDebug("Pluggable: {RequestInfo}", _requestInfo);
        }
    }
}
