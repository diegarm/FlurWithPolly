﻿using Microsoft.AspNetCore.Http;
using BancoBpi.Pluggable.API.Domain;
using BancoBpi.Pluggable.API.Interceptors;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Context
{
    public interface IPluggableExecutionContext
    {
        string GetRequestId();

        void SetRequestId(HttpContext context);

        [MonitoringInterceptor]
        void SetContextInfo(HttpContext context);

        IContextInfo GetContextInfo();


        [MonitoringInterceptor]
        Task SetRequestInfoAsync(HttpContext context);

        RequestInfo GetRequestInfo();
    }
}
