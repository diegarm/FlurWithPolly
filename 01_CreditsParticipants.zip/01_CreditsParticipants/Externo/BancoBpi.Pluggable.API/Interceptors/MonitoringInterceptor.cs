﻿using AspectCore.DynamicProxy;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using OpenTelemetry.Trace;
using BancoBpi.Pluggable.API.Context;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Interceptors
{
    // TODO: Esta classe deveria ser eliminada... Para que serve?
    public class MonitoringInterceptor : AbstractInterceptorAttribute
    {
        public const string Source = "Microsoft.AspNetCore";

        public async override Task Invoke(AspectContext context, AspectDelegate next)
        {
            string spanName = context.ProxyMethod.DeclaringType.Name + "." + context.ProxyMethod.Name;
            ILogger logger = (ILogger)context.ServiceProvider.GetService(typeof(ILogger<MonitoringInterceptor>));
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            try
            {
                var tracer = TracerProvider.Default.GetTracer(MonitoringInterceptor.Source);
                using var span = tracer.StartActiveSpan(spanName);
                span.SetStatus(Status.Error);
                await next(context); // Run the function                                
                span.SetStatus(Status.Ok);
            }
            finally
            {
                stopWatch.Stop();
                // Get the elapsed time as a TimeSpan value.
                long totalTime = stopWatch.ElapsedMilliseconds;
                logger.LogDebug("Pluggable: [Interceptor Monitoring] {spanName} duration {Service.TimeTaken}", spanName, totalTime);
            }
        }
    }
}
