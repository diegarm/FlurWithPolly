﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Tools
{
    public static class Serialize
    {
        public static string ToJson(this object obj)
        {
            var options = new JsonSerializerOptions();
            options.WriteIndented = true;
            return JsonSerializer.Serialize(obj, options);
        }

        public static T FromJson<T>(this string obj)
        {
            return JsonSerializer.Deserialize<T>(obj);
        }
    }
}
