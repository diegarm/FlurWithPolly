﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Hateoas
{
    public interface IHateoasGenerator
    {
        public HateoasLink Make(string resource);
        public typeOfLinks MakeLinks<typeOfLinks>(string propertyName, HateoasLink hateoasLink);
        public typeOfLink MakeLink<typeOfLink>(HateoasLink hateoasLink);
    }
}
