﻿using BancoBpi.Pluggable.API.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.Pluggable.API.Hateoas
{
    public class HateoasGenerator : IHateoasGenerator
    {
        private IPluggableExecutionContext _pluggContext;

        public HateoasGenerator(IPluggableExecutionContext pluggContext)
        {
            this._pluggContext = pluggContext;
        }

        public HateoasLink Make(string resource)
        {
            if (resource.StartsWith("/"))
            {
                resource = resource.Substring(1);
            }
            HateoasLink link = new HateoasLink();
            var info = _pluggContext.GetRequestInfo().ForwardInfo;
            link.Href = $"{info.Proto}://{info.Host}{info.Prefix}{resource}".ToLower();
            return link;
        }

        public typeOfLinks MakeLinks<typeOfLinks>(string propertyName, HateoasLink hateoasLink)
        {
            var linksContructor = typeof(typeOfLinks).GetConstructor(new Type[] { });
            typeOfLinks obj = (typeOfLinks)linksContructor.Invoke(null);
            var prop = typeof(typeOfLinks).GetProperty(propertyName);
            prop.SetValue(obj, MakeLink(prop.PropertyType, hateoasLink));
            return obj;
        }


        public typeOfLink MakeLink<typeOfLink>(HateoasLink hateoasLink)
        {

            return (typeOfLink)MakeLink(typeof(typeOfLink), hateoasLink);
        }

        private static object MakeLink(Type typeOfLink, HateoasLink hateoasLink)
        {
            var linkContructor = typeOfLink.GetConstructor(new Type[] { });
            object linkObj = linkContructor.Invoke(null);
            PropertyInfo href = GetPropertyInfoByName(typeOfLink, "href");
            if (href != null)
            {
                href.SetValue(linkObj, hateoasLink.Href);
            }
            return linkObj;
        }

        private static Dictionary<Type, Dictionary<string, PropertyInfo>> _cachePropertyInfo = new();

        private static PropertyInfo GetPropertyInfoByName(Type typeOfLink, string name)
        {
            Dictionary<string, PropertyInfo> props = null;
            PropertyInfo propInfo = null;

            if (!_cachePropertyInfo.ContainsKey(typeOfLink))
            {
                props = new Dictionary<string, PropertyInfo>();
                _cachePropertyInfo[typeOfLink] = props;
            }
            else
            {
                props = _cachePropertyInfo[typeOfLink];
            }

            if (!props.ContainsKey(name))
            {
                propInfo = GetPropertyInfoByNameInternal(typeOfLink, name);
                props[name] = propInfo;
            }
            else
            {
                propInfo = props[name];
            }
            return propInfo;
        }

        private static PropertyInfo GetPropertyInfoByNameInternal(Type typeOfLink, string name)
        {
            name = name.ToLower();
            foreach (var href in typeOfLink.GetProperties())
            {
                if (href.Name.ToLower().Equals(name))
                {
                    return href;
                }
            }
            return null;
        }
    }
}
