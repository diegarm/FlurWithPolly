﻿using BancoBpi.Pluggable.API.Context;

namespace BancoBpi.Pluggable.API.Hateoas
{
    public class KindGenerator : IKindGenerator
    {
        private readonly IPluggableExecutionContext _executionContext;

        public KindGenerator(IPluggableExecutionContext executionContext)
        {
            _executionContext = executionContext;
        }

        public string Make()
        {          
            var forwardInfo = _executionContext.GetRequestInfo().ForwardInfo;

            var runtimeInfo = _executionContext.GetRequestInfo().ApiRuntimeInfo;

            var apiName = runtimeInfo.Name;
            
            var apiVersiom = runtimeInfo.MajorVersion;

            return $"{apiName}/{apiVersiom}/{forwardInfo.Resource}".ToLower();
        }
    }
}
