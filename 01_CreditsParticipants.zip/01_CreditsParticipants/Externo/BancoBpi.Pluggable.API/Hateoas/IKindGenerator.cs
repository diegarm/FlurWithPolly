﻿namespace BancoBpi.Pluggable.API.Hateoas
{
    public interface IKindGenerator
    {
        public string Make();
    }
}
