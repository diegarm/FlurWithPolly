﻿BancoBPI.FAST.Pluggable.API

Dll for suport of FAST architeture micorservices.

Contains basic funcionality for using in Fast Pluggable Template V2.
