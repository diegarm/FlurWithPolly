﻿using BancoBpi.Infrastructure.EntityFramework.Execption;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace BancoBpi.Infrastructure.EntityFramework.Context
{
    internal static class DataBaseContext
    {
        internal static void AddSQL(this IServiceCollection services, IConfiguration configuration, string connectionString)
        {
            try
            {
                if (String.IsNullOrEmpty(connectionString))
                    throw new PluggDataException("Connection is null");

                services.AddDbContext<ApplicationContext>(
                context => context.UseSqlServer(configuration.GetConnectionString(connectionString)));
            }            
            catch (Exception ex)
            {
                throw new PluggDataException("It was possible add Context of SQL Server.", ex);
            }

        }


        internal static void AddPostgreSQL(this IServiceCollection services, IConfiguration configuration, string connectionString)
        {
            try
            {
                if (String.IsNullOrEmpty(connectionString))
                    throw new PluggDataException("Connection is null");

                services.AddDbContext<ApplicationContext>(
                context => context.UseNpgsql(configuration.GetConnectionString(connectionString)));
            }
            catch (Exception ex)
            {
                throw new PluggDataException("It was possible add Context of SQL Server.", ex);
            }

        }

    }
}
