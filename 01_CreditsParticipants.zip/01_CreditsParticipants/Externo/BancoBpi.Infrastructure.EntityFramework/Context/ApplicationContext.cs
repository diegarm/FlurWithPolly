﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace BancoBpi.Infrastructure.EntityFramework.Context
{
    public class ApplicationContext : DbContext
    {
        private Assembly _assembly;

        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {

        }

        public void SetAssembly(Assembly assembly)
        {
            _assembly = assembly;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            if(_assembly is not null)
                modelBuilder.ApplyConfigurationsFromAssembly(_assembly);

            base.OnModelCreating(modelBuilder);
        }
    }
}
