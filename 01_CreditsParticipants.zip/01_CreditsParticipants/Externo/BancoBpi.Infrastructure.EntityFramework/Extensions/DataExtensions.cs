﻿using BancoBpi.Infrastructure.EntityFramework.Context;
using BancoBpi.Infrastructure.EntityFramework.Repository;
using BancoBpi.Infrastructure.EntityFramework.Enum;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BancoBpi.Infrastructure.EntityFramework.Extensions
{
    public static class DataExtensions
    {

        public static void AddDataBase(this IServiceCollection services,
                                              IConfiguration configuration,
                                              Provider database,
                                              string connectionString)
        {
            services.AddScoped(typeof(UnitOfWork<>));

            switch (database)
            {
                case Provider.SQL:
                    DataBaseContext.AddSQL(services, configuration, connectionString);
                    break;
                case Provider.PostgreSQL:
                    DataBaseContext.AddPostgreSQL(services, configuration, connectionString);
                    break;
            }
            
                        
        }

    
    }
}
