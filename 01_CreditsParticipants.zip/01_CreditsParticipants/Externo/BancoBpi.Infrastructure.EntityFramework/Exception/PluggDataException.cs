﻿namespace BancoBpi.Infrastructure.EntityFramework.Execption
{
    public class PluggDataException : System.Exception
    {
        public PluggDataException(string message, System.Exception innerException) : base(message, innerException)
        {

        }

        public PluggDataException(string message) : base(message)
        {

        }
    }
}
