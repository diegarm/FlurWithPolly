﻿using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pluggable.DataAccess.Repository.Interfaces
{
    public interface ITransaction
    {
        Task<IDbContextTransaction> CreateTransaction();

        Task<IDbContextTransaction> CreateTransaction(System.Data.IsolationLevel isolation = System.Data.IsolationLevel.Serializable);
    }
}
