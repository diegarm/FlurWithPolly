﻿$: << File.join(ENV["BASE_PATH"], "../_Tools/Build/MrBuild")
require 'mrbuild'

class BuildDotNetCoreTask < Task
	def execute
		envPath = File.join(@build_spec.working_dir_path,"/environment.txt").gsub!('/', '\\')
		command_line = "echo #{ENV["CODELINE"].upcase} > #{envPath}"
		system(command_line)

		FileUtils.cp(File.join(@build_spec.working_dir_path,"/deployConfigFiles/NuGet.Config"), File.join(@build_spec.working_dir_path,"/NuGet.Config"))
		command_line = "#{File.join(@build_spec.working_dir_path,"/deployConfigFiles/build.bat")}"
		exec_and_log(command_line)
	end
end

class TestDotNetCoreTask < Task
	def execute
		command_line = "#{File.join(@build_spec.working_dir_path,"/deployConfigFiles/test.bat")}"
		exec_and_log(command_line)
	end
end

task :setup_custom_specs do

	$registry[:compile_net_core] = BuildDotNetCoreTask
	$registry[:run_dot_net_unit_tests] = TestDotNetCoreTask

end 
