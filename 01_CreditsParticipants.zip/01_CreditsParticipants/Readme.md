Build Local
docker build -t credit-participant -f DockerfileLocal .



1 - docker build -f ./DockerfileNoBuild -t de.icr.io/pt-bancobpi/creditparticipantsapi-v1:1.0.0-alpha1 .
2 - docker build -t creditparticipantsapi-v1:1.0.0-alpha1 . --build-arg BUILD_VERSION=1.0.0-alpha1
3 - docker images
4 - docker image rm <Image_ID> --force