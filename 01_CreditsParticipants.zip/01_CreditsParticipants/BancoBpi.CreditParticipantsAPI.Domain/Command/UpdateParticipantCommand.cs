﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Domain.Command
{
    public class UpdateParticipantCommand
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string XMLData { get; set; }

        public List<string> Nationalities { get; set; } = new List<string>();
        public DateTime BirthDate { get; set; }
        public string PreferredContact { get; set; }

        public enum ContactTypeEnum
        {
            MobileEnum = 1,
            PhoneEnum = 2,
            FaxEnum = 3,
            EmailEnum = 4
        }

        public ContactTypeEnum ContactType { get; set; }
        public decimal TotalIncome { get; set; }
        public decimal TotalExpenses { get; set; }

        public enum GenderEnum
        {
            FemaleEnum = 1,
            MaleEnum = 2,
            OtherEnum = 3
        }

        public GenderEnum Gender { get; set; }
        public string BirthCountry { get; set; }
        public string BirthDistrict { get; set; }
        public string BirthCounty { get; set; }
        public string BirthParish { get; set; }
        public enum MaritalStatusEnum
        {
            DivorcedEnum = 1,
            DomesticPartnerEnum = 2,
            MarriedEnum = 3,
            SingleEnum = 4,
            WidowedEnum = 5
        }

        public MaritalStatusEnum MaritalStatus { get; set; }
        public enum MarriageRegimeEnum
        {
            AcquiredEnum = 1,
            FreelyEnum = 2,
            GeneralEnum = 3,
            SeparationPropEnum = 4
        }

        public MarriageRegimeEnum MarriageRegime { get; set; }
        public string AcademicTitle { get; set; }
        public string AcademicGrade { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string Profession { get; set; }
        public string ProfessionalRole { get; set; }
        public DateTime AdmissionDate { get; set; }
        public string EmployerName { get; set; }
        public string ActivityCode { get; set; }
        public enum ProfessionalStatusEnum
        {
            WorkerEnum = 1,
            EmployeeEnum = 2,
            SelfEmployedEnum = 3,
            UnemployedEnum = 4
        }
        public ProfessionalStatusEnum ProfessionalStatus { get; set; }
    }
}
