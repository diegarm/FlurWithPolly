﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Domain.Entities
{
    public class ParticipantCommand
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }

        public int TotalIncome { get; set; }

        public int TotalExpenses { get; set; }

        public enum MaritalStatusEnum
        {
            DivorcedEnum = 1,
            DomesticPartnerEnum = 2,
            MarriedEnum = 3,
            SingleEnum = 4,
            WidowedEnum = 5
        }
        public MaritalStatusEnum MaritalStatus { get; set; }

        public enum ProfessionalStatusEnum
        {
            WorkerEnum = 1,
            EmployeeEnum = 2,
            SelfEmployedEnum = 3,
            UnemployedEnum = 4
        }

        public ProfessionalStatusEnum ProfessionalStatus { get; set; }
    }
}
