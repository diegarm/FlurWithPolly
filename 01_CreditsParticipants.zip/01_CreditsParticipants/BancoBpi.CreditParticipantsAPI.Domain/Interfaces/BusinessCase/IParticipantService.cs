﻿using BancoBpi.CreditParticipantsAPI.Domain.Command;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Domain.Interfaces.BusinessCase
{
    public interface IParticipantService
    {

        Task<ParticipantDomain> CreateParticipant(ParticipantCommand participant);

        Task<ParticipantDomain> FindParticipant(string id);
        Task<ParticipantDomain> UpdateParticipant(UpdateParticipantCommand input);
    }
}
