﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Domain.Interfaces.Repository
{
    public interface IRepository<T>
    {
        Task<T> GetByIdAsync(object id);
        Task<T> CreateAsync(T entity);
        Task<T> UpdateAsync(T entity);

    }
}
