SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[T_APICreditoParticipante](
	[Id] [nvarchar](max) NOT NULL,
	[Dados] [nvarchar](max) NULL,
	[DataInclusao] [datetime] NOT NULL,
	[DataAlteracao] [datetime] NOT NULL,
	[InseridoPor] [nvarchar](max) NULL,
	[AlteradoPor] [nvarchar](max) NULL
	
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[T_APICreditoParticipante] ADD  CONSTRAINT [PK_part] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
