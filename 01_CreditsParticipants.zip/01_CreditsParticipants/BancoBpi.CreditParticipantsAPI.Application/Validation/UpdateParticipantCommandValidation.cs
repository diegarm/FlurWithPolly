﻿using BancoBpi.CreditParticipantsAPI.Application.Constants;
using BancoBpi.CreditParticipantsAPI.Domain.Command;
using FluentValidation;
using System;

namespace BancoBpi.CreditParticipantsAPI.Application.Validation
{
    public class UpdateParticipantCommandValidation<T> : AbstractValidator<T> where T : UpdateParticipantCommand
    {
        public UpdateParticipantCommandValidation()
        {
            CheckRules();
        }

        public void CheckRules()
        {
            RuleFor(x => x.TotalIncome)
                .GreaterThan(0)
                .WithMessage(x => ValidationMessages.INVALID_TOTAL_INCOME);

            RuleFor(x => x.TotalExpenses)
              .GreaterThan(0)
              .WithMessage(x => ValidationMessages.INVALID_TOTAL_EXPENSES);

            When(p => p.ContactType != 0, () =>
            {
                RuleFor(x => x.ContactType)
                    .NotEmpty()
                    .WithMessage(ValidationMessages.CONTECTTYPE_REQUIRED)
                    .DependentRules(() =>
                    {
                       // Email
                       When(d => d.ContactType == UpdateParticipantCommand.ContactTypeEnum.EmailEnum, () =>
                        {
                            RuleFor(d => d.PreferredContact).NotEmpty().WithMessage(ValidationMessages.EMAIL_REQUIRED)
                                .EmailAddress().WithMessage(ValidationMessages.INVALID_EMAIL);
                        });

                       // Phone
                       When(d => d.ContactType == UpdateParticipantCommand.ContactTypeEnum.PhoneEnum, () =>
                        {
                            RuleFor(x => x.PreferredContact)
                               .NotEmpty()
                               .WithMessage(ValidationMessages.PHONE_REQUIRED);

                            When(y => y.PreferredContact != "" && y.PreferredContact is not null, () =>
                                 RuleFor(x => x.PreferredContact)
                                  .Must(x => x.IsValidContactNumber())
                                  .WithMessage(ValidationMessages.INVALID_PHONE_NUMBER));
                        });

                       // Fax
                       When(d => d.ContactType == UpdateParticipantCommand.ContactTypeEnum.FaxEnum, () =>
                        {
                            RuleFor(x => x.PreferredContact)
                               .NotEmpty()
                               .WithMessage(ValidationMessages.FAX_REQUIRED);

                            When(y => y.PreferredContact != "" && y.PreferredContact is not null, () =>
                                 RuleFor(x => x.PreferredContact)
                                  .Must(x => x.IsValidContactNumber())
                                  .WithMessage(ValidationMessages.INVALID_FAX_NUMBER));
                        });

                       // Mobile
                       When(d => d.ContactType == UpdateParticipantCommand.ContactTypeEnum.MobileEnum, () =>
                        {
                            RuleFor(x => x.PreferredContact)
                               .NotEmpty()
                               .WithMessage(ValidationMessages.MOBILE_REQUIRED);

                            When(y => y.PreferredContact != "" && y.PreferredContact is not null, () =>
                                 RuleFor(x => x.PreferredContact)
                                  .Must(x => x.IsValidContactNumber())
                                  .WithMessage(ValidationMessages.INVALID_MOBILE_NUMBER));
                        });

                    });
            });


            When(p => p.PreferredContact != "" && p.ContactType == 0, () =>
            {
                RuleFor(x => x.ContactType)
                 .NotEmpty()
                    .WithMessage(ValidationMessages.CONTECTTYPE_REQUIRED_WHEN_PREFEREDCONTACT_HAS_VALUE);

            });


            RuleFor(p => p.BirthDate)
                .NotEmpty().WithMessage(ValidationMessages.BIRTHDATE_REQUIRED)
                .Must(x => x.HasMoreThan18Years())
                .WithMessage(ValidationMessages.YOU_MUST_HAVE_18_YEARS);


            When(p => p.AdmissionDate != new DateTime(), () =>
            {
                RuleFor(p => p.AdmissionDate)
                    .Must(x => x.IsLesserThanNow())
                    .WithMessage(ValidationMessages.ADMISSIONDATE_LESS_THAN_NOW);
            });
        }
    }
}
