﻿using BancoBpi.CreditParticipantsAPI.Application.Constants;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Application.Validation
{
    public class ParticipantCommandValidation<T> : AbstractValidator<T> where T : ParticipantCommand
    {
        public ParticipantCommandValidation()
        {
            CheckRules();
        }

        public void CheckRules()
        {
            RuleFor(x => x.TotalIncome)
               .GreaterThan(0)
               .WithMessage(x => ValidationMessages.INVALID_TOTAL_INCOME);

            RuleFor(x => x.TotalExpenses)
              .GreaterThan(0)
              .WithMessage(x => ValidationMessages.INVALID_TOTAL_EXPENSES);


            RuleFor(p => p.BirthDate)
                .NotEmpty().WithMessage(ValidationMessages.BIRTHDATE_REQUIRED)
                .Must(x => x.HasMoreThan18Years())
                .WithMessage(ValidationMessages.YOU_MUST_HAVE_18_YEARS);
        }
    }
}
