﻿using FluentValidation;
using System.Text.RegularExpressions;
using System;
using System.Linq;
using FluentValidation.Validators;

namespace BancoBpi.CreditParticipantsAPI.Application.Validation
{
    public static class CustomValidators
    {
        public static IRuleBuilderOptions<T, string> MatchContactNumberRule<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            // verfica se o parametro introduzido contem apenas numeros válidos para um telefone
            var regularExpress = new RegularExpressionValidator<T>(@"((?:[0-9]\-?){6,14}[0-9]$)|((?:[0-9]\x20?){6,14}[0-9]$)");
            return ruleBuilder.SetValidator(regularExpress);
        }

        public static bool IsValidContactNumber(this string contact)
        {
            // Check if exists character data
            string charCharacter = @"[a-zA-Z]";
            bool hasAlpha = Regex.IsMatch(contact, charCharacter);
            if (hasAlpha == true)
                return false;

            //Check if exists special characters 
            if (contact.Any(ch => !Char.IsLetterOrDigit(ch)))
                return false;

            string motif = @"((?:[0-9]\-?){6,14}[0-9]$)|((?:[0-9]\x20?){6,14}[0-9]$)";
            bool isContactNumber = Regex.IsMatch(contact, motif, RegexOptions.IgnoreCase);
            return isContactNumber;
        }

        public static bool HasMoreThan18Years(this DateTime date)
        {
            DateTime zeroTime = new DateTime(1, 1, 1);
            DateTime now = System.DateTime.Now;
            TimeSpan span = now - date;

            int years = (zeroTime + span).Year - 1;

            return (years >= 18);
        }

        public static bool IsLesserThanNow(this DateTime date)
        {
            return date <= DateTime.Now;
        }

    }
}
