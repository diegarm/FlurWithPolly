﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Application.Constants
{
    public class ValidationMessages
    {
        public static string INVALID_TOTAL_INCOME = "Please enter valid TotalIncome";
        public static string INVALID_TOTAL_EXPENSES = "Please enter valid TotalExpenses";
        public static string EMAIL_REQUIRED = "Email is Required";
        public static string INVALID_EMAIL = "Invalid Email Address";
        public static string INVALID_CONTACT_NUMBER = "Please provide valid contact number";
        public static string BIRTHDATE_REQUIRED = "BirthDate Required";
        public static string YOU_MUST_HAVE_18_YEARS = "You must have 18 years old";
        public static string CONTECTTYPE_REQUIRED = "ContactType is Required";

        public static string MOBILE_REQUIRED = "Mobile is Required";
        public static string PHONE_REQUIRED = "Phone is Required";
        public static string FAX_REQUIRED = "Fax is Required";

        public static string INVALID_PHONE_NUMBER = "Please provide valid phone number";
        public static string INVALID_FAX_NUMBER = "Please provide valid fax number";
        public static string INVALID_MOBILE_NUMBER = "Please provide valid mobile number";

        public static string INVALID_GUID = "Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).";
        public static string ERROR_AUTOMAPPER = "Error automapper";
        public static string ERROR_SERVICE = "Error on service ";
        public static string ERROR_MODEL_VALIDATION = "Error on Model Validation ";

        public static string ADMISSIONDATE_REQUIRED = "AdmissionDate Required";
        public static string ADMISSIONDATE_LESS_THAN_NOW = "AdmissionDate must be lesser than now";

        public static string CONTECTTYPE_REQUIRED_WHEN_PREFEREDCONTACT_HAS_VALUE = "ContactType is Required when prefered contact has value";


    }
}
