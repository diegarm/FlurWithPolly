﻿using AutoMapper;
using BancoBpi.CreditParticipantsAPI.APIDomain.Models;
using BancoBpi.CreditParticipantsAPI.Domain.Command;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Application.Mapping
{
    public class GeneralProfileApp : Profile
    {

        public GeneralProfileApp()
        {
            CreateMap<ParticipantDomain, ParticipantCommand>().ReverseMap();
            CreateMap<ParticipantDomain, UpdateParticipantCommand>().ReverseMap();
            CreateMap<ParticipantDomain, IndividualParticipantOutputDetailed>().ReverseMap();            
        }       

    }
}
