﻿using AutoMapper;
using BancoBpi.CreditParticipantsAPI.Application.Constants;
using BancoBpi.CreditParticipantsAPI.Application.Exceptions;
using BancoBpi.CreditParticipantsAPI.Application.Validation;
using BancoBpi.CreditParticipantsAPI.Domain.Command;
using BancoBpi.CreditParticipantsAPI.Domain.Entities;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.BusinessCase;
using BancoBpi.CreditParticipantsAPI.Domain.Interfaces.Repository;
using BancoBpi.Pluggable.API.Exceptions;
using FluentValidation.Results;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BancoBpi.CreditParticipantsAPI.Application.BusinessCase
{
    public class ParticipantService : IParticipantService
    {
        private readonly IMapper _mapper;
        private readonly ILogger<ParticipantService> _logger;
        private readonly IParticipantDomainRepository _personRepository;

        public ParticipantService(IMapper mapper, ILogger<ParticipantService> logger, IParticipantDomainRepository personRepository)
        {
            _mapper = mapper;
            _logger = logger;
            _personRepository = personRepository;
        }

        public async Task<ParticipantDomain> CreateParticipant(ParticipantCommand command)
        {
            ParticipantDomain persistedParticipant = null;

            try
            {
                _logger.LogDebug("[CreateParticipant] - Start of Create");

                _logger.LogDebug("[CreateParticipant] - Validation");
                var validation = new ParticipantCommandValidation<ParticipantCommand>().Validate(command);

                if (!validation.IsValid)
                    throw new ValidationException(validation);

                _logger.LogDebug("[CreateParticipant] - Mapper");
                var participantDomain = _mapper.Map<ParticipantDomain>(command);

                _logger.LogDebug("[CreateParticipant] - Insert repository");
                persistedParticipant = await _personRepository.CreateAsync(participantDomain);

                _logger.LogDebug("Finish of ParticipantsService method CreateParticipant");
            }
            catch (Exception ex)
            {
                _logger.LogError(ValidationMessages.ERROR_SERVICE + "CreateParticipant", ex);
                throw;
            }

            return persistedParticipant;
        }

        public async Task<ParticipantDomain> FindParticipant(string id)
        {
            try
            {
                _logger.LogDebug($"[FindParticipant] - Start of Find - {id}");


                _logger.LogDebug("[CreateParticipant] - Searching the repository");
                var persistedParticipant = await _personRepository.GetByIdAsync(id);

                if (persistedParticipant == null)
                    throw new NotFoundException("Participant not found");

                return persistedParticipant;

            }
            catch (Exception ex)
            {
                _logger.LogError(ValidationMessages.ERROR_SERVICE + "FindParticipant", ex);
                throw;
            }
        }

        public async Task<ParticipantDomain> UpdateParticipant(UpdateParticipantCommand command)
        {
            ParticipantDomain persistedParticipant = null;

            try
            {
                _logger.LogDebug("[UpdateParticipant] - Start of Update");

                _logger.LogDebug("[UpdateParticipant] - Validation");
                var validation = new UpdateParticipantCommandValidation<UpdateParticipantCommand>().Validate(command);

                if (!validation.IsValid)
                    throw new ValidationException(validation);

                _logger.LogDebug("[UpdateParticipant] - Mapper");
                var participantDomain = _mapper.Map<ParticipantDomain>(command);

                _logger.LogDebug("[UpdateParticipant] - Insert repository");
                persistedParticipant = await _personRepository.UpdateAsync(participantDomain);

                _logger.LogDebug("Finish of ParticipantsService method UpdateParticipant");
            }
            catch (Exception ex)
            {
                _logger.LogError(ValidationMessages.ERROR_SERVICE + "CreateParticipant", ex);
                throw;
            }

            return persistedParticipant;
        }

    }
}
